package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.CargoDto;
import com.NowtifyLogist.Proyecto.Entity.Cargo;
import com.NowtifyLogist.Proyecto.Service.CargoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class CargoBusiness {

    @Autowired
    private CargoService cargoService;

    private List<Cargo> cargoList;

    public List<CargoDto> findAll() {
        List<CargoDto> cargoDtoList = new ArrayList<>();
        this.cargoList = this.cargoService.findAll();
        this.cargoList.stream().forEach(cargo -> {
            CargoDto cargoDto = new CargoDto();
            cargoDto.setIdCargo(cargo.getIdCargo());
            cargoDto.setNombreCargo(cargo.getNombreCargo());
            cargoDto.setDescripcion(cargo.getDescripcion());

            cargoDtoList.add(cargoDto);
        });
        return cargoDtoList;
    }

    public Cargo findById(int idCargo) {
        Cargo cargo = this.cargoService.findById(idCargo);
        if (cargo != null) {
            return this.cargoService.findById(idCargo);
        }
        return null;
    }

    public void createCargo(CargoDto cargoDto) throws Exception {
        Cargo cargo = new Cargo();
        cargo.setNombreCargo(cargoDto.getNombreCargo());
        cargo.setDescripcion(cargoDto.getDescripcion());

        this.cargoService.create(cargo);
    }

    public void updateCargo(int idCargo ,CargoDto updateCargoDto) throws Exception {
        Cargo existeCargo = cargoService.findById(idCargo);
        if (existeCargo == null) {
            throw new Exception("El cargo no existe");
        }
        existeCargo.setNombreCargo(updateCargoDto.getNombreCargo());
        existeCargo.setDescripcion(updateCargoDto.getDescripcion());

        this.cargoService.update(existeCargo);
    }

    public void deleteCargo(int idCargo) throws Exception {
        Cargo existeCargo = cargoService.findById(idCargo);
        if (existeCargo == null) {
            throw new Exception("El cargo no existe");
        }
        this.cargoService.delete(existeCargo);
    }
}
