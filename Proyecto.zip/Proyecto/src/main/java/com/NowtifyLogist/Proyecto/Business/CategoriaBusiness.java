package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.CategoriaDto;
import com.NowtifyLogist.Proyecto.Entity.Categoria;
import com.NowtifyLogist.Proyecto.Service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class CategoriaBusiness {

    @Autowired
    private CategoriaService categoriaService;

    private List<Categoria> categoriasList;

    public List<CategoriaDto> findAll() {
        List<CategoriaDto> categoriasDtoList = new ArrayList<>();
        this.categoriasList = categoriaService.findAll();
        this.categoriasList.stream().forEach(categoria -> {
            CategoriaDto categoriaDto = new CategoriaDto();
            categoriaDto.setId(categoria.getIdCategoria());
            categoriaDto.setNombre(categoria.getNombre());
            categoriaDto.setDescripcion(categoria.getDescripcion());

            categoriasDtoList.add(categoriaDto);
        });
        return categoriasDtoList;
    }

    public Categoria findById(int id) {
        Categoria categoria = new Categoria();
        if(categoria == null) {
            return this.categoriaService.findById(id);
        }
        return null;
    }

    public void createCategoria(CategoriaDto categoriaDto) throws Exception {
        Categoria categoria = new Categoria();
        categoria.setNombre(categoriaDto.getNombre());
        categoria.setDescripcion(categoriaDto.getDescripcion());

        this.categoriaService.save(categoria);
    }

    public void updateCategoria(Integer idCategoria ,CategoriaDto updateCategoriaDto) throws Exception {
        Categoria existeCategoria = categoriaService.findById(idCategoria);
        if(existeCategoria == null) {
            throw new Exception("No existe el categoria con el id: " + idCategoria);
        }
        existeCategoria.setNombre(updateCategoriaDto.getNombre());
        existeCategoria.setDescripcion(updateCategoriaDto.getDescripcion());

        this.categoriaService.update(existeCategoria);
    }

    public void deleteCategoria(Integer idCategoria) throws Exception {
        Categoria existeCategoria = categoriaService.findById(idCategoria);
        if(existeCategoria == null) {
            throw new Exception("No existe el categoria con el id: " + idCategoria);
        }
        this.categoriaService.delete(existeCategoria);
    }
}
