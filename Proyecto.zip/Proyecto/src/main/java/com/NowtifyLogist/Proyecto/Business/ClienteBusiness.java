package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.ClienteDto;
import com.NowtifyLogist.Proyecto.Entity.Cliente;
import com.NowtifyLogist.Proyecto.Service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ClienteBusiness {

    @Autowired
    private ClienteService clienteService;

    private List<Cliente> clienteList;

    public List<ClienteDto> findAll() {
        List<ClienteDto> clienteDtoList = new ArrayList<>();
        this.clienteList = clienteService.findAll();
        this.clienteList.stream().forEach(cliente -> {
            ClienteDto clienteDto = new ClienteDto();
            clienteDto.setId(cliente.getIdCliente());
            clienteDto.setNombre(cliente.getNombres());
            clienteDto.setApellido(cliente.getApellidos());
            clienteDto.setDocumento(cliente.getDocumento());
            clienteDto.setEmail(cliente.getEmail());
            clienteDto.setTelefono(cliente.getTelefono());
            clienteDto.setDireccion(cliente.getDireccion());


            clienteDtoList.add(clienteDto);
        });
        return clienteDtoList;
    }

    public Cliente findById(int id) {
        Cliente cliente = new Cliente();
        if (cliente != null) {
            return this.clienteService.findById(id);
        }
        return null;
    }

    public void createCliente(ClienteDto clienteDto)throws Exception {
        Cliente cliente = new Cliente();
        cliente.setNombres(clienteDto.getNombre());
        cliente.setApellidos(clienteDto.getApellido());
        cliente.setDocumento(clienteDto.getDocumento());
        cliente.setEmail(clienteDto.getEmail());
        cliente.setTelefono(clienteDto.getTelefono());
        cliente.setDireccion(clienteDto.getDireccion());

        this.clienteService.save(cliente);
    }

    public void updateCliente (Integer idCliente, ClienteDto updateClienteDto)throws Exception {
        Cliente existeCliente = this.findById(idCliente);
        if (existeCliente == null) {
            throw new Exception("El cliente no existe");
        }
        existeCliente.setNombres(updateClienteDto.getNombre());
        existeCliente.setApellidos(updateClienteDto.getApellido());
        existeCliente.setDocumento(updateClienteDto.getDocumento());
        existeCliente.setEmail(updateClienteDto.getEmail());
        existeCliente.setTelefono(updateClienteDto.getTelefono());

        this.clienteService.save(existeCliente);
    }

    public void deleteCliente (Integer idCliente)throws Exception {
        Cliente existeCliente = this.findById(idCliente);
        if (existeCliente == null) {
            throw new Exception("El cliente no existe");
        }
        this.clienteService.delete(existeCliente);
    }
}
