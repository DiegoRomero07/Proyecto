package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.CompraDto;
import com.NowtifyLogist.Proyecto.Dto.ProveedorDto;
import com.NowtifyLogist.Proyecto.Entity.Compra;
import com.NowtifyLogist.Proyecto.Entity.Proveedor;
import com.NowtifyLogist.Proyecto.Service.CompraService;
import com.NowtifyLogist.Proyecto.Service.ProveedorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class CompraBusiness {

    @Autowired
    private CompraService compraService;

    @Autowired
    private ProveedorService proveedorService;

    private List<Compra> comprasList;

    public List<CompraDto> findAll(){
        List<CompraDto> compraDtoList = new ArrayList<>();
        this.comprasList = this.compraService.findAll();
        this.comprasList.stream().forEach(compra -> {
            CompraDto compraDto = new CompraDto();
            compraDto.setId(compra.getIdCompra());
            Proveedor proveedor = compra.getProveedor();
            if (proveedor != null) {
                ProveedorDto proveedorDto = new ProveedorDto();
                proveedorDto.setId(proveedor.getIdProveedor());
                proveedorDto.setApellido(proveedor.getApellido());
                proveedorDto.setContacto(proveedor.getContacto());
                proveedorDto.setNombre(proveedor.getNombre());
                proveedorDto.setEmail(proveedor.getEmail());
                proveedorDto.setTelefono(proveedor.getTelefono());
                proveedorDto.setDireccion(proveedor.getDireccion());
                proveedorDto.setCiudad(proveedor.getCiudad());

            }
            compraDto.setFechaCompra(compra.getFechaCompra());
            compraDto.setTotalCompra(compra.getTotalCompra());

            compraDtoList.add(compraDto);
        });
        return compraDtoList;
    }

    public Compra findById(int idCompra){ return this.compraService.findById(idCompra); }

    public void createCompra(CompraDto compraDto) throws Exception{
        Compra compra = new Compra();
        ProveedorDto proveedorDto = compraDto.getIdProveedor();
        Proveedor proveedor = proveedorService.findById(proveedorDto.getId());

        if (proveedor == null) {
            throw new Exception("El proveedor no existe" + proveedorDto.getId());
        }

        compra.setFechaCompra(compraDto.getFechaCompra());
        compra.setTotalCompra(compraDto.getTotalCompra());

        this.compraService.save(compra);
    }

    public void updateCompra(int id,CompraDto updateCompraDto) throws Exception{
        Compra existeCompra = compraService.findById(id);
        if (existeCompra == null) {
            throw new Exception("El compra no existe");
        }

        if(updateCompraDto.getIdProveedor() != null){
            int idProveedor = updateCompraDto.getIdProveedor().getId();
            Proveedor proveedor = proveedorService.findById(idProveedor);
            if (proveedor == null) {
                throw new Exception("El id " + idProveedor + " no existe");
            }
            existeCompra.setProveedor(proveedor);
        }

        existeCompra.setFechaCompra(updateCompraDto.getFechaCompra());
        existeCompra.setTotalCompra(updateCompraDto.getTotalCompra());

        this.compraService.update(existeCompra);
    }

    public void deleteCompra(int idCompra) throws Exception{
        Compra existeCompra = compraService.findById(idCompra);
        if (existeCompra == null) {
            throw new Exception("El compra no existe");
        }
        this.compraService.delete(existeCompra);
    }
}
