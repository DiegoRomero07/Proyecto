package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.CompraDto;
import com.NowtifyLogist.Proyecto.Dto.DetalleCompraDto;
import com.NowtifyLogist.Proyecto.Dto.ProductoDto;
import com.NowtifyLogist.Proyecto.Entity.Compra;
import com.NowtifyLogist.Proyecto.Entity.DetalleCompra;
import com.NowtifyLogist.Proyecto.Entity.Producto;
import com.NowtifyLogist.Proyecto.Service.CompraService;
import com.NowtifyLogist.Proyecto.Service.DetalleCompraService;
import com.NowtifyLogist.Proyecto.Service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DetalleCompraBusiness {

    @Autowired
    private DetalleCompraService detalleCompraService;

    @Autowired
    private CompraService compraService;

    @Autowired
    private ProductoService productoService;

    public List<DetalleCompraDto> findAll() {
        List<DetalleCompra> detalleCompraList = this.detalleCompraService.findAll();
        List<DetalleCompraDto> detalleCompraDtoList = new ArrayList<>();

        detalleCompraList.forEach(detalleCompra -> {
            DetalleCompraDto detalleCompraDto = new DetalleCompraDto();
            detalleCompraDto.setId(detalleCompra.getIdDetalleCompra());

            Compra compra = detalleCompra.getCompra();
            if (compra != null) {
                CompraDto compraDto = new CompraDto();
                compraDto.setId(compra.getIdCompra());
                compraDto.setFechaCompra(compra.getFechaCompra());
                compraDto.setTotalCompra(compra.getTotalCompra());
                detalleCompraDto.setIdCompra(compraDto);
            }

            Producto producto = detalleCompra.getProducto();
            if (producto != null){
                ProductoDto productoDto = new ProductoDto();
                productoDto.setReferencia(producto.getReferencia());
                productoDto.setDescripcion(producto.getDescripcion());
                productoDto.setMedida(producto.getMedida());
                productoDto.setDiametro(producto.getDiametro());
                productoDto.setLargo(producto.getLargo());
                productoDto.setPrecio(producto.getPrecio());
                productoDto.setCantidad(producto.getCantidad());
                detalleCompraDto.setIdProducto(productoDto);
            }

            detalleCompraDto.setCantidadCompra(detalleCompra.getCantidadCompra());
            detalleCompraDto.setPrecioUnitario(detalleCompra.getPrecioUnitario());

            detalleCompraDtoList.add(detalleCompraDto);
        });
        return detalleCompraDtoList;
    }

    public DetalleCompraDto findById(int idDetalleCompra) {
        DetalleCompra detalleCompra = this.detalleCompraService.findById(idDetalleCompra);
        if (detalleCompra == null) {
            return null;
        }
        return convertToDto(detalleCompra);
    }

    public void createDetalleCompra(DetalleCompraDto detalleCompraDto) throws Exception {
        DetalleCompra detalleCompra = new DetalleCompra();

        Compra compra = compraService.findById(detalleCompraDto.getIdCompra().getId());
        Producto producto = productoService.findById(detalleCompraDto.getIdProducto().getReferencia()).orElse(null);

        if (compra == null) {
            throw new Exception("Compra no encontrada con el ID: " + detalleCompraDto.getIdCompra().getId());
        }
        if (producto == null) {
            throw new Exception("Producto no encontrado con la referencia: " + detalleCompraDto.getIdProducto().getReferencia());
        }

        detalleCompra.setCompra(compra);
        detalleCompra.setProducto(producto);
        detalleCompra.setCantidadCompra(detalleCompraDto.getCantidadCompra());
        detalleCompra.setPrecioUnitario(detalleCompraDto.getPrecioUnitario());

        this.detalleCompraService.save(detalleCompra);
    }

    public void updateDetalleCompra(int id, DetalleCompraDto updateDetalleCompraDto) throws Exception {
        DetalleCompra existeDetalleCompra = detalleCompraService.findById(id);
        if (existeDetalleCompra == null){
            throw new Exception("Detalle de Compra no encontrado");
        }

        if (updateDetalleCompraDto.getIdCompra() != null) {
            int idCompra = updateDetalleCompraDto.getIdCompra().getId();
            Compra compra = compraService.findById(idCompra);
            if (compra == null) {
                throw new Exception("El id de compra " + idCompra + " no se encuentra");
            }
            existeDetalleCompra.setCompra(compra);
        }

        if (updateDetalleCompraDto.getIdProducto() != null) {
            String referencia = updateDetalleCompraDto.getIdProducto().getReferencia();
            Producto producto = productoService.findById(referencia).orElse(null);
            if (producto == null) {
                throw new Exception("El id del producto " + referencia + " no se encuentra");
            }
            existeDetalleCompra.setProducto(producto);
        }

        existeDetalleCompra.setCantidadCompra(updateDetalleCompraDto.getCantidadCompra());
        existeDetalleCompra.setPrecioUnitario(updateDetalleCompraDto.getPrecioUnitario());

        this.detalleCompraService.update(existeDetalleCompra);
    }

    public void deleteDetalleCompra(int idDetalleCompra) throws Exception {
        DetalleCompra existeDetalleCompra = detalleCompraService.findById(idDetalleCompra);
        if (existeDetalleCompra == null) {
            throw new Exception("Detalle de Compra no encontrado");
        }
        this.detalleCompraService.delete(existeDetalleCompra);
    }

    private DetalleCompraDto convertToDto(DetalleCompra detalleCompra) {
        DetalleCompraDto detalleCompraDto = new DetalleCompraDto();
        detalleCompraDto.setId(detalleCompra.getIdDetalleCompra());
        detalleCompraDto.setCantidadCompra(detalleCompra.getCantidadCompra());
        detalleCompraDto.setPrecioUnitario(detalleCompra.getPrecioUnitario());

        Compra compra = detalleCompra.getCompra();
        if (compra != null) {
            CompraDto compraDto = new CompraDto();
            compraDto.setId(compra.getIdCompra());
            compraDto.setFechaCompra(compra.getFechaCompra());
            compraDto.setTotalCompra(compra.getTotalCompra());
            detalleCompraDto.setIdCompra(compraDto);
        }

        Producto producto = detalleCompra.getProducto();
        if (producto != null){
            ProductoDto productoDto = new ProductoDto();
            productoDto.setReferencia(producto.getReferencia());
            productoDto.setDescripcion(producto.getDescripcion());
            productoDto.setMedida(producto.getMedida());
            productoDto.setDiametro(producto.getDiametro());
            productoDto.setLargo(producto.getLargo());
            productoDto.setPrecio(producto.getPrecio());
            productoDto.setCantidad(producto.getCantidad());
            detalleCompraDto.setIdProducto(productoDto);
        }

        return detalleCompraDto;
    }
}
