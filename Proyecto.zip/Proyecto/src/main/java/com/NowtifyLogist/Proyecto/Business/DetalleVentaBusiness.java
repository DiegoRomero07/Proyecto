package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.ClienteDto;
import com.NowtifyLogist.Proyecto.Dto.DetalleVentaDto;
import com.NowtifyLogist.Proyecto.Dto.ProductoDto;
import com.NowtifyLogist.Proyecto.Dto.VentaDto;
import com.NowtifyLogist.Proyecto.Entity.Cliente;
import com.NowtifyLogist.Proyecto.Entity.DetalleVenta;
import com.NowtifyLogist.Proyecto.Entity.Producto;
import com.NowtifyLogist.Proyecto.Entity.Venta;
import com.NowtifyLogist.Proyecto.Service.ClienteService;
import com.NowtifyLogist.Proyecto.Service.DetalleVentaService;
import com.NowtifyLogist.Proyecto.Service.ProductoService;
import com.NowtifyLogist.Proyecto.Service.VentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DetalleVentaBusiness {

    @Autowired
    private DetalleVentaService detalleVentaService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private VentaService ventaService;

    @Autowired
    private ProductoService productoService;

    public List<DetalleVentaDto> findAll() {
        List<DetalleVenta> detalleVentaList = this.detalleVentaService.findAll();
        List<DetalleVentaDto> detalleVentaDtoList = new ArrayList<>();

        detalleVentaList.forEach(detalleVenta -> {
            DetalleVentaDto detalleVentaDto = new DetalleVentaDto();
            detalleVentaDto.setId(detalleVenta.getIdDetalleVenta());

            Venta venta = detalleVenta.getVenta();
            if (venta != null) {
                VentaDto ventaDto = new VentaDto();
                ventaDto.setId(venta.getIdVenta());
                ventaDto.setFechaVenta(venta.getFechaVenta());
                ventaDto.setTotal(venta.getTotal());
                detalleVentaDto.setIdVenta(ventaDto);
            }

            Producto producto = detalleVenta.getProducto();
            if (producto != null){
                ProductoDto productoDto = new ProductoDto();
                productoDto.setReferencia(producto.getReferencia());
                productoDto.setDescripcion(producto.getDescripcion());
                productoDto.setMedida(producto.getMedida());
                productoDto.setDiametro(producto.getDiametro());
                productoDto.setLargo(producto.getLargo());
                productoDto.setPrecio(producto.getPrecio());
                productoDto.setCantidad(producto.getCantidad());
                detalleVentaDto.setIdProducto(productoDto);
            }

            detalleVentaDto.setCantidadVendida(detalleVenta.getCantidadVendida());
            detalleVentaDto.setPrecioVenta(detalleVenta.getPrecioVenta());
            detalleVentaDto.setPrecioUnitario(detalleVenta.getPrecioUnitario());
            detalleVentaDto.setDescuento(detalleVenta.getDescuento());

            detalleVentaDtoList.add(detalleVentaDto);
        });
        return detalleVentaDtoList;
    }

    public DetalleVentaDto findById(int idDetalleVenta) {
        DetalleVenta detalleVenta = this.detalleVentaService.findById(idDetalleVenta);
        if (detalleVenta == null) {
            return null;
        }
        return convertToDto(detalleVenta);
    }

    public void createDetalleVenta(DetalleVentaDto detalleVentaDto) throws Exception {
        DetalleVenta detalleVenta = new DetalleVenta();

        Venta venta = ventaService.findById(detalleVentaDto.getIdVenta().getId());
        Producto producto = productoService.findById(detalleVentaDto.getIdProducto().getReferencia()).orElse(null);

        if (venta == null) {
            throw new Exception("Venta no encontrada con el ID: " + detalleVentaDto.getIdVenta().getId());
        }
        if (producto == null) {
            throw new Exception("Producto no encontrado con la referencia: " + detalleVentaDto.getIdProducto().getReferencia());
        }

        detalleVenta.setVenta(venta);
        detalleVenta.setProducto(producto);
        detalleVenta.setCantidadVendida(detalleVentaDto.getCantidadVendida());
        detalleVenta.setPrecioVenta(detalleVentaDto.getPrecioVenta());
        detalleVenta.setPrecioUnitario(detalleVentaDto.getPrecioUnitario());
        detalleVenta.setDescuento(detalleVentaDto.getDescuento());

        this.detalleVentaService.save(detalleVenta);
    }

    public void updateDetalleVenta(int id, DetalleVentaDto updateDetalleVentaDto) throws Exception {
        DetalleVenta existeDetalleVenta = detalleVentaService.findById(id);
        if (existeDetalleVenta == null){
            throw new Exception("Detalle de venta no encontrada");
        }

        if (updateDetalleVentaDto.getIdVenta() != null) {
            int idVenta = updateDetalleVentaDto.getIdVenta().getId();
            Venta venta = ventaService.findById(idVenta);
            if (venta == null) {
                throw new Exception("El ID de venta " + idVenta + " no se encuentra");
            }
            existeDetalleVenta.setVenta(venta);
        }

        if (updateDetalleVentaDto.getIdProducto() != null) {
            String referencia = updateDetalleVentaDto.getIdProducto().getReferencia();
            Producto producto = productoService.findById(referencia).orElse(null);
            if (producto == null) {
                throw new Exception("El ID del producto " + referencia + " no se encuentra");
            }
            existeDetalleVenta.setProducto(producto);
        }

        existeDetalleVenta.setCantidadVendida(updateDetalleVentaDto.getCantidadVendida());
        existeDetalleVenta.setPrecioVenta(updateDetalleVentaDto.getPrecioVenta());
        existeDetalleVenta.setPrecioUnitario(updateDetalleVentaDto.getPrecioUnitario());
        existeDetalleVenta.setDescuento(updateDetalleVentaDto.getDescuento());

        this.detalleVentaService.update(existeDetalleVenta);
    }

    public void deleteDetalleVenta(int idDetalleVenta) throws Exception {
        DetalleVenta existeDetalleVenta = detalleVentaService.findById(idDetalleVenta);
        if (existeDetalleVenta == null) {
            throw new Exception("Detalle de venta no encontrada");
        }
        this.detalleVentaService.delete(existeDetalleVenta);
    }

    private DetalleVentaDto convertToDto(DetalleVenta detalleVenta) {
        DetalleVentaDto detalleVentaDto = new DetalleVentaDto();
        detalleVentaDto.setId(detalleVenta.getIdDetalleVenta());
        detalleVentaDto.setCantidadVendida(detalleVenta.getCantidadVendida());
        detalleVentaDto.setPrecioVenta(detalleVenta.getPrecioVenta());
        detalleVentaDto.setPrecioUnitario(detalleVenta.getPrecioUnitario());
        detalleVentaDto.setDescuento(detalleVenta.getDescuento());

        Venta venta = detalleVenta.getVenta();
        if (venta != null) {
            VentaDto ventaDto = new VentaDto();
            ventaDto.setId(venta.getIdVenta());
            ventaDto.setFechaVenta(venta.getFechaVenta());
            ventaDto.setTotal(venta.getTotal());
            detalleVentaDto.setIdVenta(ventaDto);

            Cliente cliente = venta.getCliente(); // Aquí se obtiene el cliente de la venta
            if (cliente != null){
                ClienteDto clienteDto = new ClienteDto();
                clienteDto.setId(cliente.getIdCliente());
                clienteDto.setDocumento(cliente.getDocumento());
                clienteDto.setNombre(cliente.getNombres());
                clienteDto.setApellido(cliente.getApellidos());
                clienteDto.setEmail(cliente.getEmail());
                clienteDto.setTelefono(cliente.getTelefono());
                clienteDto.setDireccion(cliente.getDireccion());
                ventaDto.setIdCliente(clienteDto); // Asegúrate de que VentaDto tiene un campo ClienteDto
            }
        }

        Producto producto = detalleVenta.getProducto();
        if (producto != null) {
            ProductoDto productoDto = new ProductoDto();
            productoDto.setReferencia(producto.getReferencia());
            productoDto.setDescripcion(producto.getDescripcion());
            productoDto.setMedida(producto.getMedida());
            productoDto.setDiametro(producto.getDiametro());
            productoDto.setLargo(producto.getLargo());
            productoDto.setPrecio(producto.getPrecio());
            productoDto.setCantidad(producto.getCantidad());
            detalleVentaDto.setIdProducto(productoDto);
        }

        return detalleVentaDto;
    }
}
