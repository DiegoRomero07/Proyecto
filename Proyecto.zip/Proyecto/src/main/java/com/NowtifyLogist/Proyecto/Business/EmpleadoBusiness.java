package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.CargoDto;
import com.NowtifyLogist.Proyecto.Dto.EmpleadoDto;
import com.NowtifyLogist.Proyecto.Entity.Cargo;
import com.NowtifyLogist.Proyecto.Entity.Empleado;
import com.NowtifyLogist.Proyecto.Service.CargoService;
import com.NowtifyLogist.Proyecto.Service.EmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class EmpleadoBusiness {

    @Autowired
    private EmpleadoService empleadoService;

    @Autowired
    private CargoService cargoService;

    private List<Empleado> empleadoList;

    public List<EmpleadoDto> findAll(){
        List<EmpleadoDto> empleadoDtoList = new ArrayList<>();
        this.empleadoList = empleadoService.findAll();
        this.empleadoList.stream().forEach(empleado -> {
            EmpleadoDto empleadoDto = new EmpleadoDto();
            empleadoDto.setId(empleado.getIdEmpleado());
            Cargo cargo = empleado.getCargo();
            if (cargo != null){
                CargoDto cargoDto = new CargoDto();
                cargoDto.setIdCargo(cargo.getIdCargo());
                cargoDto.setNombreCargo(cargo.getNombreCargo());
                cargoDto.setDescripcion(cargo.getDescripcion());
            }

            empleadoDto.setNombre(empleado.getNombres());
            empleadoDto.setApellido(empleado.getApellidos());
            empleadoDto.setDocumento(empleado.getDocumento());
            empleadoDto.setEmail(empleado.getEmail());
            empleadoDto.setTelefono(empleado.getTelefono());

            empleadoDtoList.add(empleadoDto);
        });
        return empleadoDtoList;
    }

    public Empleado findById(int id){ return this.empleadoService.findById(id);}

    public void createEmpleado(EmpleadoDto empleadoDto) throws Exception{
        Empleado empleado = new Empleado();
        CargoDto cargoDto = empleadoDto.getIdCargo();
        Cargo cargo = cargoService.findById(cargoDto.getIdCargo());
        if (cargo == null){
            throw new Exception("Cargo no encontrado");
        }
        empleado.setNombres(empleadoDto.getNombre());
        empleado.setApellidos(empleadoDto.getApellido());
        empleado.setDocumento(empleadoDto.getDocumento());
        empleado.setEmail(empleadoDto.getEmail());
        empleado.setTelefono(empleadoDto.getTelefono());

        this.empleadoService.save(empleado);
    }

    public void updateEmpleado(int id, EmpleadoDto updateEmpleadoDto) throws Exception{
        Empleado existeEmpleado = empleadoService.findById(id);
        if (existeEmpleado == null){
            throw new Exception("Empleado no encontrado");
        }

        if(updateEmpleadoDto.getIdCargo() != null){
            int idCargo = updateEmpleadoDto.getIdCargo().getIdCargo();
            Cargo cargo = cargoService.findById(idCargo);
            if (cargo == null){
                throw new Exception("Cargo no encontrado");
            }
            existeEmpleado.setCargo(cargo);
        }

        existeEmpleado.setNombres(updateEmpleadoDto.getNombre());
        existeEmpleado.setApellidos(updateEmpleadoDto.getApellido());
        existeEmpleado.setDocumento(updateEmpleadoDto.getDocumento());
        existeEmpleado.setEmail(updateEmpleadoDto.getEmail());
        existeEmpleado.setTelefono(updateEmpleadoDto.getTelefono());

        this.empleadoService.update(existeEmpleado);
    }

    public void deleteEmpleado(Integer idEmpleado) throws Exception{
        Empleado existeEmpleado = empleadoService.findById(idEmpleado);
        if (existeEmpleado == null){
            throw new Exception("Empleado no encontrado");
        }
        this.empleadoService.delete(existeEmpleado);
    }
}
