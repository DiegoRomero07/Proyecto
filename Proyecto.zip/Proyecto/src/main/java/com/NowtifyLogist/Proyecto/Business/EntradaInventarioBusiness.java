package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.EntradaInventarioDto;
import com.NowtifyLogist.Proyecto.Dto.ProductoDto;
import com.NowtifyLogist.Proyecto.Entity.EntradaInventario;
import com.NowtifyLogist.Proyecto.Entity.Producto;
import com.NowtifyLogist.Proyecto.Service.EntradaInventarioService;
import com.NowtifyLogist.Proyecto.Service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class EntradaInventarioBusiness {

    @Autowired
    private EntradaInventarioService entradaInventarioService;

    @Autowired
    private ProductoService productoService;

    private List<EntradaInventario> listaEntradaInventario;

    public List<EntradaInventarioDto> findAll() {
        List<EntradaInventarioDto> entradaInventarioDtoList = new ArrayList<>();
        this.listaEntradaInventario = this.entradaInventarioService.findAll();
        this.listaEntradaInventario.stream().forEach(entradaInventario -> {
            EntradaInventarioDto entradaInventarioDto = new EntradaInventarioDto();
            entradaInventarioDto.setId(entradaInventario.getIdEntradaInventario());
            Producto producto = entradaInventario.getProducto();
            if (producto != null) {
                ProductoDto productoDto = new ProductoDto();
                productoDto.setReferencia(producto.getReferencia());
                productoDto.setDescripcion(producto.getDescripcion());
                productoDto.setMedida(producto.getMedida());
                productoDto.setDiametro(producto.getDiametro());
                productoDto.setLargo(producto.getLargo());
                productoDto.setPrecio(producto.getPrecio());
                productoDto.setCantidad(producto.getCantidad());
            }

            entradaInventarioDto.setCantidadEntrada(entradaInventario.getCantidadEntrada());
            entradaInventarioDto.setFechaEntrada(entradaInventario.getFechaEntrada());
            entradaInventarioDto.setPrecioUnitario(entradaInventario.getPrecioUnitario());
            entradaInventarioDto.setPrecioTotal(entradaInventario.getTotal());

            entradaInventarioDtoList.add(entradaInventarioDto);
        });
        return entradaInventarioDtoList;
    }

    public EntradaInventario findById(int idEntradaInventario) { return this.entradaInventarioService.findById(idEntradaInventario);}

    public void createEntradaInventario(EntradaInventarioDto entradaInventarioDto) throws Exception{
        EntradaInventario entradaInventario = new EntradaInventario();
        ProductoDto productoDto = entradaInventarioDto.getIdProducto();
        Optional<Producto> producto = productoService.findById(productoDto.getReferencia());

        if (producto == null) {
            throw new Exception("No existe el producto");
        }

        entradaInventario.setCantidadEntrada(entradaInventarioDto.getCantidadEntrada());
        entradaInventario.setFechaEntrada(entradaInventarioDto.getFechaEntrada());
        entradaInventario.setPrecioUnitario(entradaInventarioDto.getPrecioUnitario());
        entradaInventario.setTotal(entradaInventarioDto.getPrecioTotal());

        this.entradaInventarioService.save(entradaInventario);
    }

    public void updateEntradaInventario(int idEntradaInventario, EntradaInventarioDto updateentradaInventarioDto) throws Exception{
        EntradaInventario existeEntrada = entradaInventarioService.findById(idEntradaInventario);
        if (existeEntrada == null) {
            throw new Exception("No existe el entrada");
        }

        if (updateentradaInventarioDto.getIdProducto() != null){
            String Referencia = updateentradaInventarioDto.getIdProducto().getReferencia();
            Optional<Producto> producto = productoService.findById(Referencia);
            if (producto == null){
                throw new Exception("No existe el producto");
            }
            existeEntrada.setProducto(producto.get());
        }

        existeEntrada.setCantidadEntrada(updateentradaInventarioDto.getCantidadEntrada());
        existeEntrada.setFechaEntrada(updateentradaInventarioDto.getFechaEntrada());
        existeEntrada.setPrecioUnitario(updateentradaInventarioDto.getPrecioUnitario());
        existeEntrada.setTotal(updateentradaInventarioDto.getPrecioTotal());

        this.entradaInventarioService.update(existeEntrada);
    }

    public void deteleEntradaInventario(int idEntradaInventario) throws Exception {
        EntradaInventario existeEntrada = entradaInventarioService.findById(idEntradaInventario);
        if (existeEntrada == null) {
            throw new Exception("Entrada no encontrado");
        }

        this.entradaInventarioService.delete(existeEntrada);
    }
}
