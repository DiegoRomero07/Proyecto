package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.EstadoPqrsDto;
import com.NowtifyLogist.Proyecto.Entity.EstadoPqrs;
import com.NowtifyLogist.Proyecto.Service.EstadoPqrsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class EstadoPqrsBusiness {

    @Autowired
    private EstadoPqrsService estadoPqrsService;

    private List<EstadoPqrs> listaEstadoPqrs;

    public List<EstadoPqrsDto> findAll() {
        List<EstadoPqrsDto> estadoPqrsDtoList = new ArrayList<>();
        this.listaEstadoPqrs = estadoPqrsService.findAll();
        this.listaEstadoPqrs.stream().forEach(estadoPqrs -> {
            EstadoPqrsDto estadoPqrsDto = new EstadoPqrsDto();
            estadoPqrsDto.setId(estadoPqrsDto.getId());
            estadoPqrsDto.setNombreEstado(estadoPqrs.getNombreEstado());

            estadoPqrsDtoList.add(estadoPqrsDto);
        });
        return estadoPqrsDtoList;
    }

    public EstadoPqrs findById(int id) { return this.estadoPqrsService.findById(id); }

    public void createEstadoPqrs(EstadoPqrsDto estadoPqrsDto) {
        EstadoPqrs estadoPqrs = new EstadoPqrs();
        estadoPqrs.setNombreEstado(estadoPqrsDto.getNombreEstado());

        this.estadoPqrsService.save(estadoPqrs);
    }

    public void updateEstadoPqrs(int id, EstadoPqrsDto updateEstadoPqrsDto) throws Exception {
        EstadoPqrs existeEstadoPqrs = this.estadoPqrsService.findById(id);
        if (existeEstadoPqrs == null) {
            throw new Exception("Estado no encontrado");
        }
        existeEstadoPqrs.setNombreEstado(updateEstadoPqrsDto.getNombreEstado());
    }
    public void deleteEstadoPqrs(int id) throws Exception {
        EstadoPqrs estadoPqrs = this.estadoPqrsService.findById(id);
        if (estadoPqrs == null) {
            throw new Exception("Estado no encontrado");
        }
        this.estadoPqrsService.delete(estadoPqrs);
    }
}
