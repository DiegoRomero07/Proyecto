package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.EstadoSolicitudDto;
import com.NowtifyLogist.Proyecto.Entity.EstadoSolicitud;
import com.NowtifyLogist.Proyecto.Service.EstadoSolicitudService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class EstadoSolicitudBusiness {

    @Autowired
    private EstadoSolicitudService estadoSolicitudService;

    private List<EstadoSolicitud> estadoSolicitudList;

    public List<EstadoSolicitudDto> findAll() {
        List<EstadoSolicitudDto> estadoSolicitudDtoList = new ArrayList<>();
        this.estadoSolicitudList = this.estadoSolicitudService.findAll();
        this.estadoSolicitudList.stream().forEach(estadoSolicitud -> {
            EstadoSolicitudDto estadoSolicitudDto = new EstadoSolicitudDto();
            estadoSolicitudDto.setId(estadoSolicitud.getIdEstadoSolicitud());
            estadoSolicitudDto.setNombreEstado(estadoSolicitud.getNombreEstado());

            estadoSolicitudDtoList.add(estadoSolicitudDto);
        });
        return estadoSolicitudDtoList;
    }

    public EstadoSolicitud findById(int id){ return this.estadoSolicitudService.findById(id); }

    public void creteEstadoSolicitud(EstadoSolicitudDto estadoSolicitudDto) throws Exception{
        EstadoSolicitud estadoSolicitud = new EstadoSolicitud();
        estadoSolicitud.setNombreEstado(estadoSolicitudDto.getNombreEstado());

        this.estadoSolicitudService.save(estadoSolicitud);
    }

    public void updateEstadoSolicitud(int id, EstadoSolicitudDto updateEstadoSolicitudDto) throws Exception{
        EstadoSolicitud existeEstado = this.estadoSolicitudService.findById(id);
        if (existeEstado == null) {
            throw new Exception("Estado no encontrado");
        }
        existeEstado.setNombreEstado(updateEstadoSolicitudDto.getNombreEstado());
        this.estadoSolicitudService.save(existeEstado);
    }
    public void deleteEstadoSolicitud(int idEstadoSolicitud) throws Exception{
        EstadoSolicitud existeEstado = this.estadoSolicitudService.findById(idEstadoSolicitud);
        if (existeEstado == null) {
            throw new Exception("Estado no encontrado");
        }
        this.estadoSolicitudService.delete(existeEstado);
    }
}
