package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.EstadoUsuarioDto;
import com.NowtifyLogist.Proyecto.Entity.EstadoUsuario;
import com.NowtifyLogist.Proyecto.Service.EstadoUsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class EstadoUsuarioBusiness {

    @Autowired
    private EstadoUsuarioService estadoUsuarioService;

    private List<EstadoUsuario> estadoUsuarioList;

    public List<EstadoUsuarioDto> findAll() {
        List<EstadoUsuarioDto> estadoUsuarioDtoList = new ArrayList<>();
        this.estadoUsuarioList = estadoUsuarioService.findAll();
        this.estadoUsuarioList.stream().forEach(estadoUsuario -> {
            EstadoUsuarioDto estadoUsuarioDto = new EstadoUsuarioDto();
            estadoUsuarioDto.setId(estadoUsuario.getIdEstadoUsuario());
            estadoUsuarioDto.setTipoEstado(estadoUsuario.getTipoEstado());

            estadoUsuarioDtoList.add(estadoUsuarioDto);
        });
        return estadoUsuarioDtoList;
    }

    public EstadoUsuario findById(int id) {
        return this.estadoUsuarioService.findById(id);
    }

    public void createEstadoUsuario(EstadoUsuarioDto estadoUsuarioDto) throws Exception {
        EstadoUsuario estadoUsuario = new EstadoUsuario();
        estadoUsuario.setTipoEstado(estadoUsuarioDto.getTipoEstado());

        this.estadoUsuarioService.save(estadoUsuario);
    }

    public void updateEstadoUsuario(int id, EstadoUsuarioDto estadoUsuarioDto) throws Exception {
        EstadoUsuario existeEstadoUsuario = this.estadoUsuarioService.findById(id);
        if (existeEstadoUsuario == null) {
            throw new Exception("Estado usuario no encontrado");
        }
        existeEstadoUsuario.setTipoEstado(estadoUsuarioDto.getTipoEstado());
        this.estadoUsuarioService.update(existeEstadoUsuario);
    }

    public void deleteEstadoUsuario(int id) throws Exception {
        EstadoUsuario existeEstadoUsuario = this.estadoUsuarioService.findById(id);
        if (existeEstadoUsuario == null) {
            throw new Exception("Estado usuario no encontrado");
        }

        this.estadoUsuarioService.delete(existeEstadoUsuario);
    }
}
