package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.InventarioDto;
import com.NowtifyLogist.Proyecto.Dto.ProductoDto;
import com.NowtifyLogist.Proyecto.Entity.Inventario;
import com.NowtifyLogist.Proyecto.Entity.Producto;
import com.NowtifyLogist.Proyecto.Service.InventarioService;
import com.NowtifyLogist.Proyecto.Service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class InventarioBusiness {

    @Autowired
    private InventarioService inventarioService;

    @Autowired
    private ProductoService productoService;

    public List<InventarioDto> findAll() {
        List<Inventario> inventarioList = this.inventarioService.findAll();
        List<InventarioDto> inventarioDtoList = new ArrayList<>();

        inventarioList.forEach(inventario -> {
            InventarioDto inventarioDto = convertToDto(inventario);
            inventarioDtoList.add(inventarioDto);
        });
        return inventarioDtoList;
    }

    public InventarioDto findById(int id) {
        Inventario inventario = this.inventarioService.findById(id);
        if (inventario == null) {
            return null;
        }
        return convertToDto(inventario);
    }

    public void createInventario(InventarioDto inventarioDto) throws Exception {
        Inventario inventario = new Inventario();
        ProductoDto productoDto = inventarioDto.getReferencia();
        Optional<Producto> productoOpt = productoService.findById(productoDto.getReferencia());

        if (!productoOpt.isPresent()) {
            throw new Exception("No se encontró el producto con la referencia: " + productoDto.getReferencia());
        }

        Producto producto = productoOpt.get();
        inventario.setProducto(producto);
        inventario.setCantidad(inventarioDto.getCantidad());
        inventario.setFechaAdquisicion(inventarioDto.getFechaAdquisicion());
        inventario.setEstado(inventarioDto.getEstado());
        inventario.setNotas(inventarioDto.getNotas());

        this.inventarioService.save(inventario);
    }

    public void updateInventario(int id, InventarioDto updateInventarioDto) throws Exception {
        Inventario existeInventario = inventarioService.findById(id);
        if (existeInventario == null) {
            throw new Exception("No se encontró el inventario con el ID: " + id);
        }

        if (updateInventarioDto.getReferencia() != null) {
            String referencia = updateInventarioDto.getReferencia().getReferencia();
            Optional<Producto> productoOpt = productoService.findById(referencia);
            if (!productoOpt.isPresent()) {
                throw new Exception("No se encontró el producto con la referencia: " + referencia);
            }
            Producto producto = productoOpt.get();
            existeInventario.setProducto(producto);
        }

        existeInventario.setCantidad(updateInventarioDto.getCantidad());
        existeInventario.setFechaAdquisicion(updateInventarioDto.getFechaAdquisicion());
        existeInventario.setEstado(updateInventarioDto.getEstado());
        existeInventario.setNotas(updateInventarioDto.getNotas());

        this.inventarioService.update(existeInventario);
    }

    public void deleteInventario(int id) throws Exception {
        Inventario existeInventario = inventarioService.findById(id);
        if (existeInventario == null) {
            throw new Exception("No se encontró el inventario con el ID: " + id);
        }
        this.inventarioService.delete(existeInventario);
    }

    private InventarioDto convertToDto(Inventario inventario) {
        InventarioDto inventarioDto = new InventarioDto();
        inventarioDto.setId(inventario.getIdInventario());
        inventarioDto.setCantidad(inventario.getCantidad());
        inventarioDto.setFechaAdquisicion(inventario.getFechaAdquisicion());
        inventarioDto.setEstado(inventario.getEstado());
        inventarioDto.setNotas(inventario.getNotas());

        Producto producto = inventario.getProducto();
        if (producto != null) {
            ProductoDto productoDto = new ProductoDto();
            productoDto.setReferencia(producto.getReferencia());
            productoDto.setDescripcion(producto.getDescripcion());
            productoDto.setMedida(producto.getMedida());
            productoDto.setDiametro(producto.getDiametro());
            productoDto.setLargo(producto.getLargo());
            productoDto.setPrecio(producto.getPrecio());
            productoDto.setCantidad(producto.getCantidad());
            inventarioDto.setReferencia(productoDto);
        }

        return inventarioDto;
    }
}
