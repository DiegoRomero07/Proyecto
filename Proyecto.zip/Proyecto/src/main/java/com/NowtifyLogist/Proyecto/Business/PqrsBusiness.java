package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.*;
import com.NowtifyLogist.Proyecto.Entity.*;
import com.NowtifyLogist.Proyecto.Service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class PqrsBusiness {

    @Autowired
    private PqrsService pqrsService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private EmpleadoService empleadoService;

    @Autowired
    private EstadoPqrsService estadoPqrsService;

    @Autowired
    private RespuestaPqrsService respuestaPqrsService;

    private List<Pqrs> pqrsList;

    public List<PqrsDto> findAll() {
        List<PqrsDto> pqrsDtoList = new ArrayList<>();
        this.pqrsList = this.pqrsService.findAll();
        this.pqrsList.stream().forEach(pqrs -> {
            PqrsDto pqrsDto = new PqrsDto();
            pqrsDto.setId(pqrs.getId());

            //Llave foranea en la tabla Cliente
            Cliente cliente = pqrs.getCliente();
            ClienteDto clienteDto = new ClienteDto();
            clienteDto.setId(cliente.getIdCliente());
            clienteDto.setNombre(cliente.getNombres());
            clienteDto.setApellido(cliente.getApellidos());
            clienteDto.setDocumento(cliente.getDocumento());
            clienteDto.setEmail(cliente.getEmail());
            clienteDto.setTelefono(cliente.getTelefono());
            clienteDto.setDireccion(cliente.getDireccion());

            Empleado empleado = pqrs.getEmpleado();
            EmpleadoDto empleadoDto = new EmpleadoDto();
            empleadoDto.setId(empleado.getIdEmpleado());
            empleadoDto.setNombre(empleado.getNombres());
            empleadoDto.setApellido(empleado.getApellidos());
            empleadoDto.setDocumento(empleado.getDocumento());
            empleadoDto.setEmail(empleado.getEmail());
            empleadoDto.setTelefono(empleado.getTelefono());

            EstadoPqrs estadoPqrs = pqrs.getEstadoPqrs();
            EstadoPqrsDto estadoPqrsDto = new EstadoPqrsDto();
            estadoPqrsDto.setId(estadoPqrs.getIdEstadoPqrs());
            estadoPqrsDto.setNombreEstado(estadoPqrs.getNombreEstado());

            RespuestaPqrs respuestaPqrs = pqrs.getRespuestaPqrs();
            RespuestaPqrsDto respuestaPqrsDto = new RespuestaPqrsDto();
            respuestaPqrsDto.setId(respuestaPqrs.getIdRespuestaPqrs());
            respuestaPqrsDto.setNombreRespuesta(respuestaPqrs.getNombreRespuesta());
            respuestaPqrsDto.setFechaRespuesta(respuestaPqrs.getFechaRespuesta());

            pqrsDtoList.add(pqrsDto);
        });
        return pqrsDtoList;
    }

    public Pqrs findById(int id){
        return this.pqrsService.findById(id);
    }

    public void cretePqrs(PqrsDto pqrsDto) throws Exception{
        Pqrs pqrs = new Pqrs();
        ClienteDto clienteDto = pqrsDto.getIdCliente();
        Cliente cliente = clienteService.findById(clienteDto.getId());

        pqrs.setCliente(cliente);
        pqrs.setDescripcion(pqrsDto.getDescripcion());
        pqrs.setFechaCreacion(pqrsDto.getFechaCreacion());
        pqrs.setPrioridad(pqrsDto.getPrioridad());
        pqrs.setFechaRespuesta(pqrsDto.getFechaRespuesta());

        this.pqrsService.save(pqrs);
    }

    public void updatePqrs(int id, PqrsDto updatePqrsDto) throws Exception{
        Pqrs existePqrs = pqrsService.findById(id);
        if (existePqrs == null){
            throw new Exception("Pqrs no encontrada");
        }

        existePqrs.setDescripcion(updatePqrsDto.getDescripcion());
        existePqrs.setFechaCreacion(updatePqrsDto.getFechaCreacion());
        existePqrs.setPrioridad(updatePqrsDto.getPrioridad());
        existePqrs.setFechaRespuesta(updatePqrsDto.getFechaRespuesta());

        if (updatePqrsDto.getIdCliente() != null){
            int idCliente = updatePqrsDto.getIdCliente().getId();
            Cliente cliente = clienteService.findById(idCliente);
            if (cliente == null){
                throw new Exception("El id " + idCliente + "no se encuentra");
            }
        }
        this.pqrsService.update(existePqrs);
    }

    public void deletePqrs(int id) throws Exception {
        Pqrs existePqrs = pqrsService.findById(id);
        if (existePqrs == null){
            throw new Exception("Prs no encontrada");
        }
        this.pqrsService.delete(existePqrs);
    }
}
