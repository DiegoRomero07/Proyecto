package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.CategoriaDto;
import com.NowtifyLogist.Proyecto.Dto.ProductoDto;
import com.NowtifyLogist.Proyecto.Dto.ProveedorDto;
import com.NowtifyLogist.Proyecto.Entity.Categoria;
import com.NowtifyLogist.Proyecto.Entity.Producto;
import com.NowtifyLogist.Proyecto.Entity.Proveedor;
import com.NowtifyLogist.Proyecto.Service.CategoriaService;
import com.NowtifyLogist.Proyecto.Service.ProductoService;
import com.NowtifyLogist.Proyecto.Service.ProveedorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class ProductoBusiness {

    @Autowired
    private ProductoService productoService;

    @Autowired
    private CategoriaService categoriaService;

    @Autowired
    private ProveedorService proveedorService;

    public List<ProductoDto> findAll() {
        List<Producto> productoList = productoService.findAll();
        List<ProductoDto> productoDtoList = new ArrayList<>();

        productoList.forEach(producto -> {
            ProductoDto productoDto = convertToDto(producto);
            productoDtoList.add(productoDto);
        });

        return productoDtoList;
    }

    public ProductoDto findById(String referencia) {
        Optional<Producto> producto = productoService.findById(referencia);
        return producto.map(this::convertToDto).orElse(null);
    }

    public void createProducto(ProductoDto productoDto) throws Exception {
        Producto producto = convertToEntity(productoDto);
        productoService.save(producto);
    }

    public void updateProducto(String referencia, ProductoDto updateProductoDto) throws Exception {
        Optional<Producto> optionalProducto = productoService.findById(referencia);
        if (!optionalProducto.isPresent()) {
            throw new Exception("No existe el producto");
        }

        Producto existeProducto = optionalProducto.get();
        updateEntityFromDto(existeProducto, updateProductoDto);
        productoService.update(existeProducto);
    }

    public void deleteProducto(String referencia) throws Exception {
        Optional<Producto> optionalProducto = productoService.findById(referencia);
        if (!optionalProducto.isPresent()) {
            throw new Exception("No existe el producto");
        }
        productoService.delete(optionalProducto.get());
    }

    private ProductoDto convertToDto(Producto producto) {
        ProductoDto productoDto = new ProductoDto();
        productoDto.setReferencia(producto.getReferencia());
        productoDto.setDescripcion(producto.getDescripcion());
        productoDto.setMedida(producto.getMedida());
        productoDto.setDiametro(producto.getDiametro());
        productoDto.setLargo(producto.getLargo());
        productoDto.setPrecio(producto.getPrecio());
        productoDto.setCantidad(producto.getCantidad());

        Categoria categoria = producto.getCategoria();
        CategoriaDto categoriaDto = new CategoriaDto();
        categoriaDto.setId(categoria.getIdCategoria());
        categoriaDto.setNombre(categoria.getNombre());
        categoriaDto.setDescripcion(categoria.getDescripcion());
        productoDto.setIdCategoria(categoriaDto);

        Proveedor proveedor = producto.getProveedor();
        ProveedorDto proveedorDto = new ProveedorDto();
        proveedorDto.setId(proveedor.getIdProveedor());
        proveedorDto.setNombre(proveedor.getNombre());
        proveedorDto.setApellido(proveedor.getApellido());
        proveedorDto.setContacto(proveedor.getContacto());
        proveedorDto.setEmail(proveedor.getEmail());
        proveedorDto.setTelefono(proveedor.getTelefono());
        proveedorDto.setDireccion(proveedor.getDireccion());
        proveedorDto.setCiudad(proveedor.getCiudad());
        proveedorDto.setPais(proveedor.getPais());
        productoDto.setIdProveedor(proveedorDto);

        return productoDto;
    }

    private Producto convertToEntity(ProductoDto productoDto) throws Exception {
        Producto producto = new Producto();

        Categoria categoria = categoriaService.findById(productoDto.getIdCategoria().getId());
        if (categoria == null) {
            throw new Exception("Categoría no encontrada");
        }
        Proveedor proveedor = proveedorService.findById(productoDto.getIdProveedor().getId());
        if (proveedor == null) {
            throw new Exception("Proveedor no encontrado");
        }

        producto.setReferencia(productoDto.getReferencia());
        producto.setDescripcion(productoDto.getDescripcion());
        producto.setMedida(productoDto.getMedida());
        producto.setDiametro(productoDto.getDiametro());
        producto.setLargo(productoDto.getLargo());
        producto.setPrecio(productoDto.getPrecio());
        producto.setCantidad(productoDto.getCantidad());
        producto.setCategoria(categoria);
        producto.setProveedor(proveedor);

        return producto;
    }

    private void updateEntityFromDto(Producto producto, ProductoDto updateProductoDto) throws Exception {
        producto.setReferencia(updateProductoDto.getReferencia());
        producto.setDescripcion(updateProductoDto.getDescripcion());
        producto.setMedida(updateProductoDto.getMedida());
        producto.setDiametro(updateProductoDto.getDiametro());
        producto.setLargo(updateProductoDto.getLargo());
        producto.setPrecio(updateProductoDto.getPrecio());
        producto.setCantidad(updateProductoDto.getCantidad());

        if (updateProductoDto.getIdCategoria() != null) {
            Categoria categoria = categoriaService.findById(updateProductoDto.getIdCategoria().getId());
            if (categoria == null) {
                throw new Exception("Categoría no encontrada");
            }
            producto.setCategoria(categoria);
        }

        if (updateProductoDto.getIdProveedor() != null) {
            Proveedor proveedor = proveedorService.findById(updateProductoDto.getIdProveedor().getId());
            if (proveedor == null) {
                throw new Exception("Proveedor no encontrado");
            }
            producto.setProveedor(proveedor);
        }
    }
}
