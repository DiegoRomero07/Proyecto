package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.ProductoDto;
import com.NowtifyLogist.Proyecto.Dto.ProductoProveedorDto;
import com.NowtifyLogist.Proyecto.Dto.ProveedorDto;
import com.NowtifyLogist.Proyecto.Entity.Producto;
import com.NowtifyLogist.Proyecto.Entity.ProductoProveedor;
import com.NowtifyLogist.Proyecto.Entity.Proveedor;
import com.NowtifyLogist.Proyecto.Service.ProductoProveedorService;
import com.NowtifyLogist.Proyecto.Service.ProductoService;
import com.NowtifyLogist.Proyecto.Service.ProveedorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class ProductoProveedorBusiness {

    @Autowired
    private ProductoProveedorService productoProveedorService;

    @Autowired
    private ProductoService productoService;

    @Autowired
    private ProveedorService proveedorService;

    public List<ProductoProveedorDto> findAll() {
        List<ProductoProveedor> productoProveedorList = this.productoProveedorService.findAll();
        List<ProductoProveedorDto> productoProveedorDtoList = new ArrayList<>();

        productoProveedorList.forEach(productoProveedor -> {
            ProductoProveedorDto pDto = convertToDto(productoProveedor);
            productoProveedorDtoList.add(pDto);
        });
        return productoProveedorDtoList;
    }

    public ProductoProveedorDto findById(int id) {
        ProductoProveedor productoProveedor = productoProveedorService.findById(id);
        if (productoProveedor == null) {
            return null;
        }
        return convertToDto(productoProveedor);
    }

    public void createProductoProveedor(ProductoProveedorDto productoProveedorDto) throws Exception {
        ProductoProveedor productoProveedor = new ProductoProveedor();
        ProductoDto productoDto = productoProveedorDto.getIdProducto();
        Optional<Producto> productoOpt = productoService.findById(productoDto.getReferencia());

        if (!productoOpt.isPresent()) {
            throw new Exception("No se encontró el producto con la referencia: " + productoDto.getReferencia());
        }

        Producto producto = productoOpt.get();
        productoProveedor.setProducto(producto);

        ProveedorDto proveedorDto = productoProveedorDto.getIdProveedor();
        Optional<Proveedor> proveedorOpt = Optional.ofNullable(proveedorService.findById(proveedorDto.getId()));

        if (!proveedorOpt.isPresent()) {
            throw new Exception("No se encontró el proveedor con el ID: " + proveedorDto.getId());
        }

        Proveedor proveedor = proveedorOpt.get();
        productoProveedor.setProveedor(proveedor);

        productoProveedor.setPrecioCompra(productoProveedorDto.getPrecioCompra());
        productoProveedor.setCantidadMinima(productoProveedorDto.getCantidadMinima());
        productoProveedor.setFechaUltimoPedido(productoProveedorDto.getFechaUltimoPedido());
        productoProveedor.setTiempoEntrega(productoProveedorDto.getTiempoEntrega());

        this.productoProveedorService.save(productoProveedor);
    }

    public void updateProductoProveedor(int id, ProductoProveedorDto updateProductoProveedorDto) throws Exception {
        ProductoProveedor existeProductoProveedor = productoProveedorService.findById(id);
        if (existeProductoProveedor == null) {
            throw new Exception("No existe el producto proveedor con el ID: " + id);
        }

        existeProductoProveedor.setPrecioCompra(updateProductoProveedorDto.getPrecioCompra());
        existeProductoProveedor.setCantidadMinima(updateProductoProveedorDto.getCantidadMinima());
        existeProductoProveedor.setFechaUltimoPedido(updateProductoProveedorDto.getFechaUltimoPedido());
        existeProductoProveedor.setTiempoEntrega(updateProductoProveedorDto.getTiempoEntrega());

        if (updateProductoProveedorDto.getIdProducto() != null) {
            String referencia = updateProductoProveedorDto.getIdProducto().getReferencia();
            Optional<Producto> productoOpt = productoService.findById(referencia);
            if (!productoOpt.isPresent()) {
                throw new Exception("No se encontró el producto con la referencia: " + referencia);
            }
            Producto producto = productoOpt.get();
            existeProductoProveedor.setProducto(producto);
        }

        if (updateProductoProveedorDto.getIdProveedor() != null) {
            int idProveedor = updateProductoProveedorDto.getIdProveedor().getId();
            Optional<Proveedor> proveedorOpt = Optional.ofNullable(proveedorService.findById(idProveedor));
            if (!proveedorOpt.isPresent()) {
                throw new Exception("No se encontró el proveedor con el ID: " + idProveedor);
            }
            Proveedor proveedor = proveedorOpt.get();
            existeProductoProveedor.setProveedor(proveedor);
        }

        this.productoProveedorService.update(existeProductoProveedor);
    }

    public void deleteProductoProveedor(int id) throws Exception {
        ProductoProveedor existeProductoProveedor = productoProveedorService.findById(id);
        if (existeProductoProveedor == null) {
            throw new Exception("No existe el producto proveedor con el ID: " + id);
        }
        this.productoProveedorService.delete(existeProductoProveedor);
    }

    private ProductoProveedorDto convertToDto(ProductoProveedor productoProveedor) {
        ProductoProveedorDto pDto = new ProductoProveedorDto();
        pDto.setId(productoProveedor.getIdProductoProveedor());

        Producto producto = productoProveedor.getProducto();
        if (producto != null) {
            ProductoDto productoDto = new ProductoDto();
            productoDto.setReferencia(producto.getReferencia());
            productoDto.setDescripcion(producto.getDescripcion());
            productoDto.setMedida(producto.getMedida());
            productoDto.setDiametro(producto.getDiametro());
            productoDto.setLargo(producto.getLargo());
            productoDto.setPrecio(producto.getPrecio());
            productoDto.setCantidad(producto.getCantidad());
            pDto.setIdProducto(productoDto);
        }

        Proveedor proveedor = productoProveedor.getProveedor();
        if (proveedor != null) {
            ProveedorDto proveedorDto = new ProveedorDto();
            proveedorDto.setId(proveedor.getIdProveedor());
            proveedorDto.setNombre(proveedor.getNombre());
            proveedorDto.setApellido(proveedor.getApellido());
            proveedorDto.setEmail(proveedor.getEmail());
            proveedorDto.setTelefono(proveedor.getTelefono());
            proveedorDto.setDireccion(proveedor.getDireccion());
            proveedorDto.setCiudad(proveedor.getCiudad());
            proveedorDto.setPais(proveedor.getPais());
            pDto.setIdProveedor(proveedorDto);
        }

        pDto.setPrecioCompra(productoProveedor.getPrecioCompra());
        pDto.setCantidadMinima(productoProveedor.getCantidadMinima());
        pDto.setFechaUltimoPedido(productoProveedor.getFechaUltimoPedido());
        pDto.setTiempoEntrega(productoProveedor.getTiempoEntrega());

        return pDto;
    }
}
