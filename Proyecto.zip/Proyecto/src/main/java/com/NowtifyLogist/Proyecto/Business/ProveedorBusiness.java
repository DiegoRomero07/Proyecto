package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.ProveedorDto;
import com.NowtifyLogist.Proyecto.Entity.Proveedor;
import com.NowtifyLogist.Proyecto.Service.ProveedorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ProveedorBusiness {

    @Autowired
    private ProveedorService proveedorService;

    private List<Proveedor> proveedorList;

    public List<ProveedorDto> findAll() {
        List<ProveedorDto> proveedorDtoList = new ArrayList<>();
        this.proveedorList = proveedorService.findAll();
        this.proveedorList.stream().forEach(proveedor -> {
            ProveedorDto proveedorDto = new ProveedorDto();
            proveedorDto.setId(proveedor.getIdProveedor());
            proveedorDto.setNombre(proveedor.getNombre());
            proveedorDto.setApellido(proveedor.getApellido());
            proveedorDto.setEmail(proveedor.getEmail());
            proveedorDto.setTelefono(proveedor.getTelefono());
            proveedorDto.setDireccion(proveedor.getDireccion());
            proveedorDto.setCiudad(proveedor.getCiudad());
            proveedorDto.setPais(proveedor.getPais());

            proveedorDtoList.add(proveedorDto);
        });
        return proveedorDtoList;
    }

    public Proveedor findById(int id) {
        return proveedorService.findById(id);
    }
    public void createProveedor(ProveedorDto proveedorDto) throws Exception {
        Proveedor proveedor = new Proveedor();
        proveedor.setNombre(proveedorDto.getNombre());
        proveedor.setApellido(proveedorDto.getApellido());
        proveedor.setEmail(proveedorDto.getEmail());
        proveedor.setTelefono(proveedorDto.getTelefono());
        proveedor.setDireccion(proveedorDto.getDireccion());
        proveedor.setCiudad(proveedorDto.getCiudad());
        proveedor.setPais(proveedorDto.getPais());

        this.proveedorService.save(proveedor);
    }

    public void updateProveedor(int id, ProveedorDto updateProveedorDto) throws Exception {
        Proveedor existeProveedor = this.proveedorService.findById(id);
        if (existeProveedor == null) {
            throw new Exception("No existe el proveedor");
        }
        existeProveedor.setNombre(updateProveedorDto.getNombre());
        existeProveedor.setApellido(updateProveedorDto.getApellido());
        existeProveedor.setEmail(updateProveedorDto.getEmail());
        existeProveedor.setTelefono(updateProveedorDto.getTelefono());
        existeProveedor.setDireccion(updateProveedorDto.getDireccion());
        existeProveedor.setCiudad(updateProveedorDto.getCiudad());
        existeProveedor.setPais(updateProveedorDto.getPais());

        this.proveedorService.save(existeProveedor);
    }

    public void deleteProveedor(int id) throws Exception {
        Proveedor existeProveedor = this.proveedorService.findById(id);
        if (existeProveedor == null) {
            throw new Exception("No existe el proveedor");
        }
        this.proveedorService.delete(existeProveedor);
    }
}
