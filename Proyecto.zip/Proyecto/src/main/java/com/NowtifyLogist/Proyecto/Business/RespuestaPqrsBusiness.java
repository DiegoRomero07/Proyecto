package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.RespuestaPqrsDto;
import com.NowtifyLogist.Proyecto.Entity.RespuestaPqrs;
import com.NowtifyLogist.Proyecto.Service.RespuestaPqrsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class RespuestaPqrsBusiness {

    @Autowired
    private RespuestaPqrsService respuestaPqrsService;

    private List<RespuestaPqrs> respuestaPqrsList;

    public List<RespuestaPqrs> findAll() {
        List<RespuestaPqrsDto> respuestaPqrsDtoList = new ArrayList<>();
        this.respuestaPqrsList = respuestaPqrsService.findAll();
        this.respuestaPqrsList.stream().forEach(respuestaPqrs -> {
            RespuestaPqrsDto respuestaPqrsDto = new RespuestaPqrsDto();
            respuestaPqrsDto.setId(respuestaPqrs.getIdRespuestaPqrs());
            respuestaPqrsDto.setFechaRespuesta(respuestaPqrs.getFechaRespuesta());
            respuestaPqrsDto.setNombreRespuesta(respuestaPqrs.getNombreRespuesta());

            respuestaPqrsDtoList.add(respuestaPqrsDto);
        });
        return respuestaPqrsList;
    }

    public RespuestaPqrs findById(int idRespuestaPqrs) {
        return respuestaPqrsService.findById(idRespuestaPqrs);
    }
    public void createRespuestaPqrs(RespuestaPqrsDto respuestaPqrsDto) throws Exception {
        RespuestaPqrs respuestaPqrs = new RespuestaPqrs();
        respuestaPqrs.setNombreRespuesta(respuestaPqrsDto.getNombreRespuesta());
        respuestaPqrs.setFechaRespuesta(respuestaPqrsDto.getFechaRespuesta());

        this.respuestaPqrsService.save(respuestaPqrs);
    }

    public void updateRespuestaPqrs(int id, RespuestaPqrsDto updateRespuestaPqrsDto) throws Exception {
        RespuestaPqrs existeRespuesta = respuestaPqrsService.findById(id);
        if (existeRespuesta == null) {
            throw new Exception("No se encontro el respuesta del usuario");
        }

        existeRespuesta.setNombreRespuesta(updateRespuestaPqrsDto.getNombreRespuesta());
        existeRespuesta.setFechaRespuesta(updateRespuestaPqrsDto.getFechaRespuesta());
        this.respuestaPqrsService.update(existeRespuesta);
    }

    public void deleteRespuestaPqrs(int idRespuestaPqrs) throws Exception {
        RespuestaPqrs existeRespuesta = respuestaPqrsService.findById(idRespuestaPqrs);
        if (existeRespuesta == null) {
            throw new Exception("Respuesta no encontrada");
        }
        this.respuestaPqrsService.delete(existeRespuesta);
    }
}
