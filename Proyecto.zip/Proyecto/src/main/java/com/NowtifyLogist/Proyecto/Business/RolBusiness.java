package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.RolDto;
import com.NowtifyLogist.Proyecto.Entity.Rol;
import com.NowtifyLogist.Proyecto.Service.RolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class RolBusiness {

    @Autowired
    private RolService rolService;

    private List<Rol> rolList;

    public List<RolDto> findAll() {
        List<RolDto> rolDtoList = new ArrayList<>();
        this.rolList = rolService.findAll();
        this.rolList.stream().forEach(rol -> {
            RolDto rolDto = new RolDto();
            rolDto.setId(rol.getIdRol());
            rolDto.setNombreRol(rol.getNombreRol());

            rolDtoList.add(rolDto);
        });
        return rolDtoList;
    }

    public Rol findById(int idRol) {
        return this.rolService.findById(idRol);
    }

    public void createRol(RolDto rolDto) {
        Rol rol = new Rol();
        rol.setNombreRol(rolDto.getNombreRol());

        this.rolService.save(rol);
    }

    public void updaeRol(int id, RolDto updateRolDto) throws Exception {
        Rol existeRol = rolService.findById(id);
        if (existeRol == null) {
            throw new Exception("No se encontro el rol");
        }
        existeRol.setNombreRol(updateRolDto.getNombreRol());
        this.rolService.update(existeRol);
    }

    public void deleteRol(int idRol) throws Exception {
        Rol existeRol = rolService.findById(idRol);
        if (existeRol == null) {
            throw new Exception("No se encontro el rol");
        }
        this.rolService.delete(existeRol);
    }
}
