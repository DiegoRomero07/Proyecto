package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.EmpleadoDto;
import com.NowtifyLogist.Proyecto.Dto.ProductoDto;
import com.NowtifyLogist.Proyecto.Dto.SalidaInventarioDto;
import com.NowtifyLogist.Proyecto.Entity.Empleado;
import com.NowtifyLogist.Proyecto.Entity.Producto;
import com.NowtifyLogist.Proyecto.Entity.SalidaInventario;
import com.NowtifyLogist.Proyecto.Service.EmpleadoService;
import com.NowtifyLogist.Proyecto.Service.ProductoService;
import com.NowtifyLogist.Proyecto.Service.SalidaInventarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class SalidaInventarioBusiness {

    @Autowired
    private SalidaInventarioService salidaService;

    @Autowired
    private ProductoService productoService;

    @Autowired
    private EmpleadoService empleadoService;

    public List<SalidaInventarioDto> findAll() {
        List<SalidaInventario> salidaInventarioList = salidaService.findAll();
        List<SalidaInventarioDto> salidaInventarioDtoList = new ArrayList<>();

        salidaInventarioList.forEach(salidaInventario -> {
            SalidaInventarioDto salidaInventarioDto = convertToDto(salidaInventario);
            salidaInventarioDtoList.add(salidaInventarioDto);
        });
        return salidaInventarioDtoList;
    }

    public SalidaInventarioDto findById(int id){
        SalidaInventario salidaInventario = salidaService.findById(id);
        if (salidaInventario == null) {
            return null;
        }
        return convertToDto(salidaInventario);
    }

    public void createSalida(SalidaInventarioDto salidaInventarioDto) throws Exception {
        SalidaInventario salida = new SalidaInventario();

        ProductoDto productoDto = salidaInventarioDto.getIdProducto();
        Optional<Producto> productoOpt = productoService.findById(productoDto.getReferencia());
        if (!productoOpt.isPresent()) {
            throw new Exception("No se encontró el producto con la referencia: " + productoDto.getReferencia());
        }
        Producto producto = productoOpt.get();

        EmpleadoDto empleadoDto = salidaInventarioDto.getIdEmpleado();
        Optional<Empleado> empleadoOpt = Optional.ofNullable(empleadoService.findById(empleadoDto.getId()));
        if (!empleadoOpt.isPresent()) {
            throw new Exception("No se encontró el empleado con el ID: " + empleadoDto.getId());
        }
        Empleado empleado = empleadoOpt.get();

        salida.setProducto(producto);
        salida.setEmpleado(empleado);
        salida.setFechaSalida(salidaInventarioDto.getFechaSalida());
        salida.setCantidad(salidaInventarioDto.getCantidad());
        salida.setMotivo(salidaInventarioDto.getMotivo());

        this.salidaService.save(salida);
    }

    public void updateSalida(int id, SalidaInventarioDto updateSalidaDto) throws Exception {
        SalidaInventario existeSalida = salidaService.findById(id);
        if (existeSalida == null) {
            throw new Exception("No se encontró la salida con el ID: " + id);
        }

        existeSalida.setFechaSalida(updateSalidaDto.getFechaSalida());
        existeSalida.setCantidad(updateSalidaDto.getCantidad());
        existeSalida.setMotivo(updateSalidaDto.getMotivo());

        if (updateSalidaDto.getIdProducto() != null){
            String referencia = updateSalidaDto.getIdProducto().getReferencia();
            Optional<Producto> productoOpt = productoService.findById(referencia);
            if (!productoOpt.isPresent()) {
                throw new Exception("No se encontró el producto con la referencia: " + referencia);
            }
            Producto producto = productoOpt.get();
            existeSalida.setProducto(producto);
        }

        if (updateSalidaDto.getIdEmpleado() != null) {
            int idEmpleado = updateSalidaDto.getIdEmpleado().getId();
            Optional<Empleado> empleadoOpt = Optional.ofNullable(empleadoService.findById(idEmpleado));
            if (!empleadoOpt.isPresent()) {
                throw new Exception("No se encontró el empleado con el ID: " + idEmpleado);
            }
            Empleado empleado = empleadoOpt.get();
            existeSalida.setEmpleado(empleado);
        }

        this.salidaService.update(existeSalida);
    }

    public void deleteSalida(int id) throws Exception {
        SalidaInventario existeSalida = salidaService.findById(id);
        if (existeSalida == null){
            throw new Exception("Salida no encontrada con el ID: " + id);
        }
        this.salidaService.delete(existeSalida);
    }

    private SalidaInventarioDto convertToDto(SalidaInventario salidaInventario) {
        SalidaInventarioDto salidaInventarioDto = new SalidaInventarioDto();
        salidaInventarioDto.setId(salidaInventario.getIdSalidaInventario());

        Producto producto = salidaInventario.getProducto();
        if (producto != null) {
            ProductoDto productoDto = new ProductoDto();
            productoDto.setReferencia(producto.getReferencia());
            productoDto.setDescripcion(producto.getDescripcion());
            productoDto.setMedida(producto.getMedida());
            productoDto.setDiametro(producto.getDiametro());
            productoDto.setLargo(producto.getLargo());
            productoDto.setCantidad(producto.getCantidad());
            productoDto.setPrecio(producto.getPrecio());
            salidaInventarioDto.setIdProducto(productoDto);
        }

        Empleado empleado = salidaInventario.getEmpleado();
        if (empleado != null) {
            EmpleadoDto empleadoDto = new EmpleadoDto();
            empleadoDto.setId(empleado.getIdEmpleado());
            empleadoDto.setDocumento(empleado.getDocumento());
            empleadoDto.setNombre(empleado.getNombres());
            empleadoDto.setApellido(empleado.getApellidos());
            empleadoDto.setEmail(empleado.getEmail());
            empleadoDto.setTelefono(empleado.getTelefono());
            salidaInventarioDto.setIdEmpleado(empleadoDto);
        }

        salidaInventarioDto.setFechaSalida(salidaInventario.getFechaSalida());
        salidaInventarioDto.setCantidad(salidaInventario.getCantidad());
        salidaInventarioDto.setMotivo(salidaInventario.getMotivo());

        return salidaInventarioDto;
    }
}
