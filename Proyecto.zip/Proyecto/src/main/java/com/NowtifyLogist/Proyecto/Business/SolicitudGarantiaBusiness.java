package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.ClienteDto;
import com.NowtifyLogist.Proyecto.Dto.EstadoSolicitudDto;
import com.NowtifyLogist.Proyecto.Dto.ProductoDto;
import com.NowtifyLogist.Proyecto.Dto.SolicitudGarantiaDto;
import com.NowtifyLogist.Proyecto.Entity.Cliente;
import com.NowtifyLogist.Proyecto.Entity.EstadoSolicitud;
import com.NowtifyLogist.Proyecto.Entity.Producto;
import com.NowtifyLogist.Proyecto.Entity.SolicitudGarantia;
import com.NowtifyLogist.Proyecto.Service.ClienteService;
import com.NowtifyLogist.Proyecto.Service.EstadoSolicitudService;
import com.NowtifyLogist.Proyecto.Service.ProductoService;
import com.NowtifyLogist.Proyecto.Service.SolicitudGarantiaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class SolicitudGarantiaBusiness {

    @Autowired
    private SolicitudGarantiaService solicitudService;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private ProductoService productoService;

    @Autowired
    private EstadoSolicitudService estadoService;

    public List<SolicitudGarantiaDto> findAll() {
        List<SolicitudGarantia> solicitudGarantiaList = solicitudService.findAll();
        List<SolicitudGarantiaDto> solicitudGarantiaDtoList = new ArrayList<>();

        for (SolicitudGarantia solicitudGarantia : solicitudGarantiaList) {
            SolicitudGarantiaDto solicitudGarantiaDto = convertToDto(solicitudGarantia);
            solicitudGarantiaDtoList.add(solicitudGarantiaDto);
        }

        return solicitudGarantiaDtoList;
    }

    public SolicitudGarantiaDto findById(int id) {
        SolicitudGarantia solicitudGarantia = solicitudService.findById(id);
        if (solicitudGarantia == null) {
            return null;
        }
        return convertToDto(solicitudGarantia);
    }

    public void createSolicitud(SolicitudGarantiaDto solicitudGarantiaDto) throws Exception {
        SolicitudGarantia solicitudGarantia = new SolicitudGarantia();

        ProductoDto productoDto = solicitudGarantiaDto.getIdProducto();
        Optional<Producto> producto = productoService.findById(productoDto.getReferencia());

        ClienteDto clienteDto = solicitudGarantiaDto.getIdCliente();
        Cliente cliente = clienteService.findById(clienteDto.getId());

        EstadoSolicitudDto estadoSolicitudDto = solicitudGarantiaDto.getIdEstadoSolicitud();
        EstadoSolicitud estadoSolicitud = estadoService.findById(estadoSolicitudDto.getId());

        solicitudGarantia.setProducto(producto.orElseThrow(() -> new Exception("No se encontró el producto")));
        solicitudGarantia.setCliente(cliente);
        solicitudGarantia.setEstadoSolicitud(estadoSolicitud);
        solicitudGarantia.setFechaSolicitud(solicitudGarantiaDto.getFechaSolicitud());
        solicitudGarantia.setDescripcionProblema(solicitudGarantiaDto.getDescripcionProblema());
        solicitudGarantia.setFechaSolucion(solicitudGarantiaDto.getFechaSolucion());
        solicitudGarantia.setAccionTomada(solicitudGarantiaDto.getAccionTomada());

        this.solicitudService.save(solicitudGarantia);
    }

    public void updateSolicitud(int id, SolicitudGarantiaDto updateSolicitudDto) throws Exception {
        SolicitudGarantia existeSolicitud = solicitudService.findById(id);
        if (existeSolicitud == null) {
            throw new Exception("La solicitud no existe");
        }

        existeSolicitud.setFechaSolicitud(updateSolicitudDto.getFechaSolicitud());
        existeSolicitud.setDescripcionProblema(updateSolicitudDto.getDescripcionProblema());
        existeSolicitud.setFechaSolucion(updateSolicitudDto.getFechaSolucion());
        existeSolicitud.setAccionTomada(updateSolicitudDto.getAccionTomada());

        if (updateSolicitudDto.getIdCliente() != null) {
            Cliente cliente = clienteService.findById(updateSolicitudDto.getIdCliente().getId());
            if (cliente == null) {
                throw new Exception("No se encontró el cliente con el ID: " + updateSolicitudDto.getIdCliente().getId());
            }
            existeSolicitud.setCliente(cliente);
        }

        this.solicitudService.update(existeSolicitud);
    }

    public void deleteSolicitud(int id) throws Exception {
        SolicitudGarantia existeSolicitud = solicitudService.findById(id);
        if (existeSolicitud == null) {
            throw new Exception("Solicitud no encontrada");
        }
        this.solicitudService.delete(existeSolicitud);
    }

    private SolicitudGarantiaDto convertToDto(SolicitudGarantia solicitudGarantia) {
        SolicitudGarantiaDto solicitudGarantiaDto = new SolicitudGarantiaDto();
        solicitudGarantiaDto.setId(solicitudGarantia.getIdSolicitudGarantia());

        Cliente cliente = solicitudGarantia.getCliente();
        ClienteDto clienteDto = new ClienteDto();
        clienteDto.setId(cliente.getIdCliente());
        clienteDto.setDocumento(cliente.getDocumento());
        clienteDto.setNombre(cliente.getNombres());
        clienteDto.setApellido(cliente.getApellidos());
        clienteDto.setEmail(cliente.getEmail());
        clienteDto.setTelefono(cliente.getTelefono());
        clienteDto.setDireccion(cliente.getDireccion());

        Producto producto = solicitudGarantia.getProducto();
        ProductoDto productoDto = new ProductoDto();
        productoDto.setReferencia(producto.getReferencia());
        productoDto.setDescripcion(producto.getDescripcion());
        producto.setMedida(producto.getMedida());
        productoDto.setLargo(producto.getLargo());
        productoDto.setDiametro(producto.getDiametro());
        productoDto.setPrecio(producto.getPrecio());
        productoDto.setCantidad(producto.getCantidad());

        EstadoSolicitud estadoSolicitud = solicitudGarantia.getEstadoSolicitud();
        EstadoSolicitudDto estadoSolicitudDto = new EstadoSolicitudDto();
        estadoSolicitudDto.setId(estadoSolicitud.getIdEstadoSolicitud());
        estadoSolicitudDto.setNombreEstado(estadoSolicitud.getNombreEstado());

        solicitudGarantiaDto.setFechaSolicitud(solicitudGarantia.getFechaSolicitud());
        solicitudGarantiaDto.setDescripcionProblema(solicitudGarantia.getDescripcionProblema());
        solicitudGarantiaDto.setFechaSolucion(solicitudGarantia.getFechaSolucion());
        solicitudGarantiaDto.setAccionTomada(solicitudGarantia.getAccionTomada());

        return solicitudGarantiaDto;
    }
}
