package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.EstadoUsuarioDto;
import com.NowtifyLogist.Proyecto.Dto.RolDto;
import com.NowtifyLogist.Proyecto.Dto.UsuarioDto;
import com.NowtifyLogist.Proyecto.Entity.EstadoUsuario;
import com.NowtifyLogist.Proyecto.Entity.Rol;
import com.NowtifyLogist.Proyecto.Entity.Usuario;
import com.NowtifyLogist.Proyecto.Service.EstadoUsuarioService;
import com.NowtifyLogist.Proyecto.Service.RolService;
import com.NowtifyLogist.Proyecto.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class UsuarioBusiness {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private RolService rolService;

    @Autowired
    private EstadoUsuarioService estadoUsuarioService;

    private List<Usuario> usuarioList;

    public List<UsuarioDto> findAll() {
        List<UsuarioDto> usuarioDtoList = new ArrayList<>();
        this.usuarioList = this.usuarioService.findAll();
        this.usuarioList.stream().forEach(usuario -> {
            UsuarioDto usuarioDto = new UsuarioDto();
            usuarioDto.setId(usuario.getIdUsuario());

            Rol rol = usuario.getRol();
            RolDto rolDto = new RolDto();
            rolDto.setId(rol.getIdRol());
            rolDto.setNombreRol(rol.getNombreRol());

            EstadoUsuario estadoUsuario = usuario.getEstadoUsuario();
            EstadoUsuarioDto estadoUsuarioDto = new EstadoUsuarioDto();
            estadoUsuarioDto.setId(estadoUsuario.getIdEstadoUsuario());
            estadoUsuarioDto.setTipoEstado(estadoUsuario.getTipoEstado());

            usuarioDto.setNombreUsuario(usuario.getNombreUsuario());
            usuarioDto.setCorreo(usuario.getCorreo());
            usuarioDto.setContraseña(usuario.getContrasena());
            usuarioDto.setFechaRegistro(usuario.getFechaRegistro());

            usuarioDtoList.add(usuarioDto);
        });
        return usuarioDtoList;
    }

    public Usuario findById(int id) {
        return this.usuarioService.findById(id);
    }
    public void createUsuario(UsuarioDto usuarioDto) throws Exception {
        Usuario usuario = new Usuario();
        RolDto rolDto = usuarioDto.getIdRol();
        Rol rol = rolService.findById(rolDto.getId());
        rol.setNombreRol(rolDto.getNombreRol());

        EstadoUsuarioDto estadoUsuarioDto = usuarioDto.getIdEstadoUsuario();
        EstadoUsuario estadoUsuario = estadoUsuarioService.findById(estadoUsuarioDto.getId());
        estadoUsuario.setTipoEstado(estadoUsuario.getTipoEstado());

        usuario.setNombreUsuario(usuarioDto.getNombreUsuario());
        usuario.setCorreo(usuarioDto.getCorreo());
        usuario.setContrasena(usuarioDto.getContraseña());
        usuario.setFechaRegistro(usuarioDto.getFechaRegistro());

        this.usuarioService.save(usuario);
    }

    public void updateUsuario(int id, UsuarioDto updateUsuarioDto) throws Exception {
        Usuario existeUsuario = usuarioService.findById(id);
        if (existeUsuario == null) {
            throw new Exception("Usuario no encontrado");
        }

        existeUsuario.setNombreUsuario(updateUsuarioDto.getNombreUsuario());
        existeUsuario.setCorreo(updateUsuarioDto.getCorreo());
        existeUsuario.setContrasena(updateUsuarioDto.getContraseña());
        existeUsuario.setFechaRegistro(updateUsuarioDto.getFechaRegistro());

        if (updateUsuarioDto.getIdRol() != null){
            int idRol = updateUsuarioDto.getIdRol().getId();
            Rol rol = rolService.findById(idRol);
            if (rol == null) {
                throw new Exception("Rol no encontrado");
            }
        }
        if (updateUsuarioDto.getIdEstadoUsuario() != null){
            int idEstadoUsuario = updateUsuarioDto.getIdEstadoUsuario().getId();
            EstadoUsuario estadoUsuario = estadoUsuarioService.findById(idEstadoUsuario);
            if (estadoUsuario == null) {
                throw new Exception("Estado Usuario no encontrado");
            }
        }

        this.usuarioService.update(existeUsuario);
    }

    public void deleteUsuario(int id) throws Exception {
        Usuario existeUsuario = usuarioService.findById(id);
        if (existeUsuario == null) {
            throw new Exception("Usuario no encontrado");
        }
        this.usuarioService.delete(existeUsuario);
    }
}
