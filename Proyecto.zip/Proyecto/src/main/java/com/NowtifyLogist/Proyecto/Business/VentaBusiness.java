package com.NowtifyLogist.Proyecto.Business;

import com.NowtifyLogist.Proyecto.Dto.ClienteDto;
import com.NowtifyLogist.Proyecto.Dto.VentaDto;
import com.NowtifyLogist.Proyecto.Entity.Cliente;
import com.NowtifyLogist.Proyecto.Entity.Venta;
import com.NowtifyLogist.Proyecto.Service.ClienteService;
import com.NowtifyLogist.Proyecto.Service.VentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class VentaBusiness {

    @Autowired
    private VentaService ventaService;

    @Autowired
    private ClienteService clienteService;

    private List<Venta> ventaList;

    public List<VentaDto> findAll() {
        List<VentaDto> ventaDtoList = new ArrayList<>();
        this.ventaList = ventaService.findAll();
        this.ventaList.stream().forEach(venta -> {
            VentaDto ventaDto = new VentaDto();
            ventaDto.setId(venta.getIdVenta());

            Cliente cliente = venta.getCliente();
            ClienteDto clienteDto = new ClienteDto();
            clienteDto.setId(cliente.getIdCliente());
            clienteDto.setDocumento(cliente.getDocumento());
            clienteDto.setNombre(cliente.getNombres());
            clienteDto.setApellido(cliente.getApellidos());
            clienteDto.setEmail(cliente.getEmail());
            clienteDto.setTelefono(cliente.getTelefono());
            clienteDto.setDireccion(cliente.getDireccion());

            ventaDto.setFechaVenta(venta.getFechaVenta());
            ventaDto.setTotal(venta.getTotal());

            ventaDtoList.add(ventaDto);
        });
        return ventaDtoList;
    }

    public Venta findById(int id) {
        return ventaService.findById(id);
    }

    public void createVenta(VentaDto ventaDto) {
        Venta venta = new Venta();
        ClienteDto clienteDto = ventaDto.getIdCliente();
        Cliente cliente = clienteService.findById(clienteDto.getId());

        venta.setCliente(cliente);
        venta.setFechaVenta(ventaDto.getFechaVenta());
        venta.setTotal(ventaDto.getTotal());

        this.ventaService.save(venta);
    }

    public void updateVenta(int id, VentaDto updateVentaDto) throws Exception {
        Venta existeVenta = ventaService.findById(id);
        if (existeVenta == null) {
            throw new Exception("No existe una venta con el id " + id);
        }

        existeVenta.setFechaVenta(updateVentaDto.getFechaVenta());
        existeVenta.setTotal(updateVentaDto.getTotal());

        if (updateVentaDto.getIdCliente() != null){
            int idCliente = updateVentaDto.getIdCliente().getId();
            Cliente cliente = clienteService.findById(idCliente);
            if (cliente == null) {
                throw new Exception("No existe una cliente con el id " + idCliente);
            }
        }
        this.ventaService.update(existeVenta);
    }

    public void deleteVenta(int id) throws Exception {
        Venta existeVenta = ventaService.findById(id);
        if (existeVenta == null) {
            throw new Exception("No existe una venta con el id " + id);
        }
        this.ventaService.delete(existeVenta);
    }
}
