package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.CargoBusiness;
import com.NowtifyLogist.Proyecto.Dto.CargoDto;
import com.NowtifyLogist.Proyecto.Entity.Cargo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Cargos", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class CargoController {

    @Autowired
    private CargoBusiness cargoBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllCargo() {
        Map<String, Object> response = new HashMap<>();
        List<CargoDto> listCargos = cargoBusiness.findAll();
        response.put("Status", "Success");
        response.put("Data", listCargos);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/{idCargo}")
    public ResponseEntity<Map<String, Object>> findCargoById(@PathVariable Integer idCargo) {
        try {
            Cargo cargo = cargoBusiness.findById(idCargo);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("Data", cargo);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("Message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createCargo(@RequestBody CargoDto newCargo) {
        Map<String, Object> response = new HashMap<>();
        try {
            cargoBusiness.createCargo(newCargo);
            response.put("Status", "Success");
            response.put("Data", newCargo);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("Status", "Error");
            responseMap.put("Message", e.getMessage());
            return new ResponseEntity<>(responseMap, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{idCargo}")
    public ResponseEntity<Map<String, Object>> updateCargo(@PathVariable Integer idCargo,
                                                           @RequestBody CargoDto existeCargo) {
        Map<String, Object> response = new HashMap<>();
        try {
            cargoBusiness.updateCargo(idCargo, existeCargo);
            response.put("Status", "Success");
            response.put("Data", existeCargo);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("Status", "Error");
            responseMap.put("Message", e.getMessage());
            return new ResponseEntity<>(responseMap, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{idCargo}")
    public ResponseEntity<Map<String, Object>> deleteCargo(@PathVariable Integer idCargo) {
        Map<String, Object> response = new HashMap<>();
        try {
            cargoBusiness.deleteCargo(idCargo);
            response.put("Status", "Success");
            response.put("Data", "Cargo eliminado");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("Status", "Error");
            responseMap.put("Message", e.getMessage());
            return new ResponseEntity<>(responseMap, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
