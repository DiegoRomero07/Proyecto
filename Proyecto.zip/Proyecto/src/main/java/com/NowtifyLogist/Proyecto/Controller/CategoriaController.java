package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.CategoriaBusiness;
import com.NowtifyLogist.Proyecto.Dto.CategoriaDto;
import com.NowtifyLogist.Proyecto.Entity.Categoria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Categorias", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@CrossOrigin("*")
public class CategoriaController {

    @Autowired
    private CategoriaBusiness categoriaBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAll() {
        Map<String, Object> response = new HashMap<>();
        List<CategoriaDto> listCategorias = categoriaBusiness.findAll();
        response.put("Status", "Success");
        response.put("Data", listCategorias);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/{idCategoria}")
    public ResponseEntity<Map<String, Object>> findById(@PathVariable int idCategoria) {
        try {
            Categoria categoria = categoriaBusiness.findById(idCategoria);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("Data", categoria);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("Message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> create(@RequestBody CategoriaDto newCategoria) {
        Map<String, Object> response = new HashMap<>();
        try {
            categoriaBusiness.createCategoria(newCategoria);
            response.put("Status", "Success");
            response.put("Data", newCategoria);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("Status", "Error");
            responseMap.put("Message", e.getMessage());

            return new ResponseEntity<>(responseMap, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{idCategoria}")
    public ResponseEntity<Map<String, Object>> update(@PathVariable int idCategoria,
                                                      @RequestBody CategoriaDto existeCategoria) {
        Map<String, Object> response = new HashMap<>();
        try {
            categoriaBusiness.updateCategoria(idCategoria, existeCategoria);
            response.put("Status", "Success");
            response.put("Data", existeCategoria);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("Status", "Error");
            responseMap.put("Message", e.getMessage());

            return new ResponseEntity<>(responseMap, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{idCategoria}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable int idCategoria) {
        Map<String, Object> response = new HashMap<>();
        try {
            categoriaBusiness.deleteCategoria(idCategoria);
            response.put("Status", "Success");
            response.put("Data", idCategoria);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> responseMap = new HashMap<>();
            responseMap.put("Status", "Error");
            responseMap.put("Message", e.getMessage());

            return new ResponseEntity<>(responseMap, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
