package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.ClienteBusiness;
import com.NowtifyLogist.Proyecto.Dto.ClienteDto;
import com.NowtifyLogist.Proyecto.Entity.Cliente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Clientes", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class ClienteController {
    @Autowired
    private ClienteBusiness clienteBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllCliente() {
        Map<String, Object> response = new HashMap<>();
        List<ClienteDto> listClientes = this.clienteBusiness.findAll();
        response.put("Status", "Success");
        response.put("Data", listClientes);

        return new  ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllClienteById(@PathVariable int id) {
        try {
            Cliente data = clienteBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("Data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("Message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createCliente(@RequestBody ClienteDto newCliente) {
        Map<String, Object> response = new HashMap<>();
        try {
            clienteBusiness.createCliente(newCliente);
            response.put("Status", "Success");
            response.put("Data", newCliente);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("Message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateCliente(@PathVariable int id,
                                                             @RequestBody ClienteDto existeCliente) {
        Map<String, Object> response = new HashMap<>();
        try {
            clienteBusiness.updateCliente(id, existeCliente);
            response.put("Status", "Success");
            response.put("Data", existeCliente);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("Message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteCliente(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            clienteBusiness.deleteCliente(id);
            response.put("Status", "Success");
            response.put("Data", "Cliente eliminado satisfactoriamente");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("Message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
