package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.CompraBusiness;
import com.NowtifyLogist.Proyecto.Dto.CompraDto;
import com.NowtifyLogist.Proyecto.Entity.Compra;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Compras", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class CompraController {

    @Autowired
    private CompraBusiness compraBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllCompras() {
        Map<String, Object> response = new HashMap<>();
        List<CompraDto> listCompras = this.compraBusiness.findAll();
        response.put("Status", "Sucees");
        response.put("data", listCompras);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllComprasById(@PathVariable int id) {
        try {
            Compra data = compraBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Sucees");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Erro");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createCompra(@RequestBody CompraDto newCompra) {
        Map<String, Object> response = new HashMap<>();
        try {
            compraBusiness.createCompra(newCompra);
            response.put("Status", "Sucees");
            response.put("data", newCompra);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateCompra(@PathVariable int id,
                                                            @RequestBody CompraDto existeCompra) {
        Map<String, Object> response = new HashMap<>();
        try {
            compraBusiness.updateCompra(id, existeCompra);
            response.put("Status", "Sucees");
            response.put("data", existeCompra);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteCompra(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            compraBusiness.deleteCompra(id);
            response.put("Status", "Sucees");
            response.put("data", id);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
