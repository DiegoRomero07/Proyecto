package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.DetalleCompraBusiness;
import com.NowtifyLogist.Proyecto.Dto.DetalleCompraDto;
import com.NowtifyLogist.Proyecto.Entity.DetalleCompra;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Detalles-Compras", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class DetalleCompraController {

    @Autowired
    private DetalleCompraBusiness detalleCompraBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllDetallesCompras() {
        Map<String, Object> response = new HashMap<>();
        List<DetalleCompraDto> listDetalleCompra = this.detalleCompraBusiness.findAll();
        response.put("Status", "Succes");
        response.put("data", listDetalleCompra);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllDetallesComprasById(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            DetalleCompraDto data = detalleCompraBusiness.findById(id);
            response.put("Status", "Succes");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createDetalleCompra(@RequestBody DetalleCompraDto newDetalle) {
        Map<String, Object> response = new HashMap<>();
        try {
            detalleCompraBusiness.createDetalleCompra(newDetalle);
            response.put("Status", "Succes");
            response.put("data", newDetalle);

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateDetalleCompra(@PathVariable int id,
                                                                   @RequestBody DetalleCompraDto existeDetalle) {
        Map<String, Object> response = new HashMap<>();
        try {
            detalleCompraBusiness.updateDetalleCompra(id, existeDetalle);
            response.put("Status", "Succes");
            response.put("data", existeDetalle);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteDetalleCompra(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            detalleCompraBusiness.deleteDetalleCompra(id);
            response.put("Status", "Succes");
            response.put("data", "Detalle de compra eliminado satisfactoriamente");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
