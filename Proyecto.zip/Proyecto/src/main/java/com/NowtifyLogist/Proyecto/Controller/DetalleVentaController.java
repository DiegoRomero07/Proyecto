package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.DetalleVentaBusiness;
import com.NowtifyLogist.Proyecto.Dto.DetalleVentaDto;
import com.NowtifyLogist.Proyecto.Entity.DetalleVenta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Detalles-ventas", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class DetalleVentaController {
    @Autowired
    private DetalleVentaBusiness detalleVentaBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllDetallesVenta() {
        Map<String, Object> response = new HashMap<>();
        List<DetalleVentaDto> listDetalleVenta = this.detalleVentaBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listDetalleVenta);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllDetallesVentaById(@PathVariable int id) {
        try {
            DetalleVentaDto data = detalleVentaBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createDetalleVenta(@RequestBody DetalleVentaDto newDetalle) {
        Map<String, Object> response = new HashMap<>();
        try {
            detalleVentaBusiness.createDetalleVenta(newDetalle);
            response.put("Status", "Success");
            response.put("data", newDetalle);

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateDetalleVenta(@PathVariable int id,
                                                                  @RequestBody DetalleVentaDto existeDetalle) {
        Map<String, Object> response = new HashMap<>();
        try {
            detalleVentaBusiness.updateDetalleVenta(id, existeDetalle);
            response.put("Status", "Success");
            response.put("data", existeDetalle);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteDetalleVenta(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            detalleVentaBusiness.deleteDetalleVenta(id);
            response.put("Status", "Success");
            response.put("data", id);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
