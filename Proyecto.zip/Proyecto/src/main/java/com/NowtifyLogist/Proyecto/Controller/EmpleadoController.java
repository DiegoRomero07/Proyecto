package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.EmpleadoBusiness;
import com.NowtifyLogist.Proyecto.Dto.EmpleadoDto;
import com.NowtifyLogist.Proyecto.Entity.Empleado;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Empleados", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class EmpleadoController {
    @Autowired
    private EmpleadoBusiness empleadoBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllEmpleados() {
        Map<String, Object> response = new HashMap<>();
        List<EmpleadoDto> listEmpleados = this.empleadoBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listEmpleados);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getEmpleadosById(@PathVariable int id) {
        try {
            Empleado data = empleadoBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createEmpleado(@RequestBody EmpleadoDto newEmpleado) {
        Map<String, Object> response = new HashMap<>();
        try{
            empleadoBusiness.createEmpleado(newEmpleado);
            response.put("Status", "Success");
            response.put("data", new EmpleadoDto());

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateEmpleado(@PathVariable int id,
                                                              @RequestBody EmpleadoDto existeEmpleado) {
        Map<String, Object> response = new HashMap<>();
        try {
            empleadoBusiness.updateEmpleado(id, existeEmpleado);
            response.put("Status", "Success");
            response.put("data", new EmpleadoDto());

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteEmpleado(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            empleadoBusiness.deleteEmpleado(id);
            response.put("Status", "Success");
            response.put("data", new EmpleadoDto());

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
