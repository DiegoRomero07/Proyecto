package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.EntradaInventarioBusiness;
import com.NowtifyLogist.Proyecto.Dto.EmpleadoDto;
import com.NowtifyLogist.Proyecto.Dto.EntradaInventarioDto;
import com.NowtifyLogist.Proyecto.Entity.EntradaInventario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Entradas-Inventario", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class EntradaInventarioController {
    @Autowired
    private EntradaInventarioBusiness entradaInventarioBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllEntadasInventario() {
        Map<String, Object> response = new HashMap<>();
        List<EntradaInventarioDto> listEntradas = this.entradaInventarioBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listEntradas);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getEntradasById(@PathVariable int id) {
        try {
            EntradaInventario data = entradaInventarioBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createEntrada(@RequestBody EntradaInventarioDto newEntrada) {
        Map<String, Object> response = new HashMap<>();
        try{
            entradaInventarioBusiness.createEntradaInventario(newEntrada);
            response.put("Status", "Success");
            response.put("data", new EmpleadoDto());

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateEntrada(@PathVariable int id,
                                                              @RequestBody EntradaInventarioDto existeEntrada) {
        Map<String, Object> response = new HashMap<>();
        try {
            entradaInventarioBusiness.updateEntradaInventario(id, existeEntrada);
            response.put("Status", "Success");
            response.put("data", existeEntrada);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteEntrada(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            entradaInventarioBusiness.deteleEntradaInventario(id);
            response.put("Status", "Success");
            response.put("data", "Entrada del inventario eliminada");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
