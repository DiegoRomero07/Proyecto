package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.EstadoPqrsBusiness;
import com.NowtifyLogist.Proyecto.Dto.EstadoPqrsDto;
import com.NowtifyLogist.Proyecto.Entity.EstadoPqrs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Estados-Pqrs", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class EstadoPqrsController {

    @Autowired
    private EstadoPqrsBusiness estadoPqrsBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllEstadoPqrs() {
        Map<String, Object> response = new HashMap<>();
        List<EstadoPqrsDto> listEstados = this.estadoPqrsBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listEstados);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getEstadosById(@PathVariable int id) {
        try {
            EstadoPqrs data = estadoPqrsBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createEstados(@RequestBody EstadoPqrsDto newEstado) {
        Map<String, Object> response = new HashMap<>();
        try{
            estadoPqrsBusiness.createEstadoPqrs(newEstado);
            response.put("Status", "Success");
            response.put("data", newEstado);

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateEstados(@PathVariable int id,
                                                             @RequestBody EstadoPqrsDto existeEstado) {
        Map<String, Object> response = new HashMap<>();
        try {
            estadoPqrsBusiness.updateEstadoPqrs(id, existeEstado);
            response.put("Status", "Success");
            response.put("data", existeEstado);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteEstados(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            estadoPqrsBusiness.deleteEstadoPqrs(id);
            response.put("Status", "Success");
            response.put("data", "Entrada del inventario eliminada");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
