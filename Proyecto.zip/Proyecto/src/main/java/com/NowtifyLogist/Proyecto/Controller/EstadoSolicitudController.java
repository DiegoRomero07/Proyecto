package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.EstadoSolicitudBusiness;
import com.NowtifyLogist.Proyecto.Dto.EstadoSolicitudDto;
import com.NowtifyLogist.Proyecto.Entity.EstadoSolicitud;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Estados-Solicitudes", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class EstadoSolicitudController {
    @Autowired
    private EstadoSolicitudBusiness estadoSolicitudBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllEstadoSolicitud() {
        Map<String, Object> response = new HashMap<>();
        List<EstadoSolicitudDto> listEstado = this.estadoSolicitudBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listEstado);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllEstadoSolicitudById(@PathVariable int id) {
        try {
            EstadoSolicitud data = estadoSolicitudBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> CreateEstadoSolicitud(@RequestBody EstadoSolicitudDto newEstado) {
        Map<String, Object> response = new HashMap<>();
        try {
            estadoSolicitudBusiness.creteEstadoSolicitud(newEstado);
            response.put("Status", "Success");
            response.put("message", "Estado solicitud creada con exito");

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> UpdateEstadoSolicitud(@PathVariable int id,
                                                                     @RequestBody EstadoSolicitudDto existeEstado) {
        Map<String, Object> response = new HashMap<>();
        try {
            estadoSolicitudBusiness.updateEstadoSolicitud(id, existeEstado);
            response.put("Status", "Success");
            response.put("message", "Estado solicitud actualizada con exito");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> DeleteEstadoSolicitud(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            estadoSolicitudBusiness.deleteEstadoSolicitud(id);
            response.put("Status", "Success");
            response.put("message", "Estado solicitud eliminado con exito");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
