package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.EstadoUsuarioBusiness;
import com.NowtifyLogist.Proyecto.Dto.EstadoUsuarioDto;
import com.NowtifyLogist.Proyecto.Entity.EstadoUsuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Estados-Usuarios", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class EstadoUsuarioController {
    @Autowired
    private EstadoUsuarioBusiness estadoUsuarioBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllEstadoUsuarios() {
        Map<String, Object> response = new HashMap<>();
        List<EstadoUsuarioDto> listEstados = estadoUsuarioBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listEstados);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getEstadoUsuariosById(@PathVariable int id) {
        try {
            EstadoUsuario data = estadoUsuarioBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createEstadoUsuario(@RequestBody EstadoUsuarioDto newEstado) {
        Map<String, Object> response = new HashMap<>();
        try {
            estadoUsuarioBusiness.createEstadoUsuario(newEstado);
            response.put("Status", "Success");
            response.put("data", newEstado);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateEstadoUsuario(@PathVariable int id,
                                                                   @RequestBody EstadoUsuarioDto existeEstado) {
        Map<String, Object> response = new HashMap<>();
        try {
            estadoUsuarioBusiness.updateEstadoUsuario(id, existeEstado);
            response.put("Status", "Success");
            response.put("data", existeEstado);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteEstadoUsuario(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            estadoUsuarioBusiness.deleteEstadoUsuario(id);
            response.put("Status", "Success");
            response.put("data", "Eliminado satisfactoriamente");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
