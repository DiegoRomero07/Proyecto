package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.InventarioBusiness;
import com.NowtifyLogist.Proyecto.Dto.InventarioDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Inventario", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class InventarioController {
    @Autowired
    private InventarioBusiness inventarioBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllInventario() {
        Map<String, Object> response = new HashMap<>();
        List<InventarioDto> listInventario = inventarioBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listInventario);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllInventarioById(@PathVariable int id) {
        try {
            InventarioDto data = inventarioBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> CreateInventario(@RequestBody InventarioDto newInventario) {
        Map<String, Object> response = new HashMap<>();
        try {
            inventarioBusiness.createInventario(newInventario);
            response.put("Status", "Success");
            response.put("data", newInventario);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> UpdateInventario(@PathVariable int id,
                                                                @RequestBody InventarioDto existeInventario) {
        Map<String, Object> response = new HashMap<>();
        try {
            inventarioBusiness.updateInventario(id, existeInventario);
            response.put("Status", "Success");
            response.put("data", existeInventario);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> DeleteInventario(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            inventarioBusiness.deleteInventario(id);
            response.put("Status", "Success");
            response.put("data", "Inventario eliminado");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
