package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.PqrsBusiness;
import com.NowtifyLogist.Proyecto.Dto.PqrsDto;
import com.NowtifyLogist.Proyecto.Entity.Pqrs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Pqrs", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class PqrsController {

    @Autowired
    private PqrsBusiness pqrsBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllPqrs() {
        Map<String, Object> response = new HashMap<>();
        List<PqrsDto> listPqrs = pqrsBusiness.findAll();
        response.put("Status", "Success");
        response.put("Pqrs", listPqrs);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllPqrsById(@PathVariable int id) {
        try {
            Pqrs data = pqrsBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("Pqrs", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e){
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> getCreatePqrs(@RequestBody PqrsDto newPqrs) {
        Map<String, Object> response = new HashMap<>();
        try {
            pqrsBusiness.cretePqrs(newPqrs);
            response.put("Status", "Success");
            response.put("Pqrs", newPqrs);

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e){
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> getUpdatePqrs(@PathVariable int id,
                                                             @RequestBody PqrsDto existePqrs) {
        Map<String, Object> response = new HashMap<>();
        try {
            pqrsBusiness.updatePqrs(id, existePqrs);
            response.put("Status", "Success");
            response.put("Pqrs", existePqrs);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e){
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> getDeletePqrs(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            pqrsBusiness.deletePqrs(id);
            response.put("Status", "Success");
            response.put("Pqrs", "Pqrs eliminado satisfactoriamente");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e){
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
