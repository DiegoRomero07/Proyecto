package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.ProductoBusiness;
import com.NowtifyLogist.Proyecto.Dto.ProductoDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Productos", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class ProductoController {
    @Autowired
    private ProductoBusiness productoBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllProductos() {
        Map<String, Object> response = new HashMap<>();
        List<ProductoDto> listProductos = productoBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listProductos);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("all/{id}")
    public ResponseEntity<Map<String, Object>> getAllProductos(@PathVariable String id) {
        try {
            ProductoDto data = productoBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e){
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> getCreateProducto(@RequestBody ProductoDto newProducto) {
        Map<String, Object> response = new HashMap<>();
        try {
            productoBusiness.createProducto(newProducto);
            response.put("Status", "Success");
            response.put("data", newProducto);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e){
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/id")
    public ResponseEntity<Map<String, Object>> getUpdateProducto(@PathVariable String id,
                                                                 @RequestBody ProductoDto existeProducto) {
        Map<String, Object> response = new HashMap<>();
        try {
            productoBusiness.updateProducto(id, existeProducto);
            response.put("Status", "Success");
            response.put("data", existeProducto);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e){
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> getDeleteProducto(@PathVariable String id) {
        Map<String, Object> response = new HashMap<>();
        try {
            productoBusiness.deleteProducto(id);
            response.put("Status", "Success");
            response.put("data", "Producto eliminado");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e){
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
