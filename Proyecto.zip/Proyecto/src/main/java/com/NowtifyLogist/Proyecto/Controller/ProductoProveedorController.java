package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.ProductoProveedorBusiness;
import com.NowtifyLogist.Proyecto.Dto.ProductoProveedorDto;
import com.NowtifyLogist.Proyecto.Entity.ProductoProveedor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Productos-Proveedores", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class ProductoProveedorController {
    @Autowired
    private ProductoProveedorBusiness ProductoProveedorBusiness;
    @Autowired
    private ProductoProveedorBusiness productoProveedorBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAll() {
        Map<String, Object> response = new HashMap<>();
        List<ProductoProveedorDto> list = ProductoProveedorBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", list);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> findById(@PathVariable int id) {
        try {
            ProductoProveedorDto data = ProductoProveedorBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> create(@RequestBody ProductoProveedorDto newProductoProveedor) {
        Map<String, Object> response = new HashMap<>();
        try {
            ProductoProveedorBusiness.createProductoProveedor(newProductoProveedor);
            response.put("Status", "Success");
            response.put("data", newProductoProveedor);

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> update(@PathVariable int id,
                                                      @RequestBody ProductoProveedorDto existe) {
        Map<String, Object> response = new HashMap<>();
        try {
            productoProveedorBusiness.updateProductoProveedor(id, existe);
            response.put("Status", "Success");
            response.put("data", existe);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            productoProveedorBusiness.deleteProductoProveedor(id);
            response.put("Status", "Success");
            response.put("data", "eliminado satisfactoriamente");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
