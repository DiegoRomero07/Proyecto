package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.ProductoProveedorBusiness;
import com.NowtifyLogist.Proyecto.Business.ProveedorBusiness;
import com.NowtifyLogist.Proyecto.Dto.ProveedorDto;
import com.NowtifyLogist.Proyecto.Entity.Proveedor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Proveedores", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class ProveedorController {
    @Autowired
    private ProveedorBusiness proveedorBusiness;
    @Autowired
    private ProductoProveedorBusiness productoProveedorBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllProveedores(){
        Map<String, Object> response = new HashMap<>();
        List<ProveedorDto> listProveedores = proveedorBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listProveedores);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> findAllProveedoresById(@PathVariable int id){
        Map<String, Object> response = new HashMap<>();
        try {
            Proveedor data = proveedorBusiness.findById(id);
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createNewProveedor(@RequestBody ProveedorDto newProveedor){
        Map<String, Object> response = new HashMap<>();
        try {
            proveedorBusiness.createProveedor(newProveedor);
            response.put("Status", "Success");
            response.put("data", newProveedor);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e){
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateProveedor(@PathVariable int id,
                                                               @RequestBody ProveedorDto existeProveedor){
        Map<String, Object> response = new HashMap<>();
        try {
            proveedorBusiness.createProveedor(existeProveedor);
            response.put("Status", "Success");
            response.put("data", existeProveedor);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e){
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteProveedor(@PathVariable int id){
        Map<String, Object> response = new HashMap<>();
        try {
            proveedorBusiness.deleteProveedor(id);
            response.put("Status", "Success");
            response.put("data", "eliminado satisfactoriamente");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e){
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
