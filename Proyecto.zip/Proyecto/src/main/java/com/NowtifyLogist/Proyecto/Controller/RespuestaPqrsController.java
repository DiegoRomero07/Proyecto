package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.RespuestaPqrsBusiness;
import com.NowtifyLogist.Proyecto.Dto.RespuestaPqrsDto;
import com.NowtifyLogist.Proyecto.Entity.RespuestaPqrs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Respuestas-Pqrs", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class RespuestaPqrsController {
    @Autowired
    private RespuestaPqrsBusiness repuestaBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllRespuestas() {
        Map<String, Object> response = new HashMap<>();
        List<RespuestaPqrs> listRespuesta = repuestaBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listRespuesta);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllRespuestasById(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            RespuestaPqrs data = repuestaBusiness.findById(id);
            Map<String, Object> respuesta = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("data", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createRespuesta(@RequestBody RespuestaPqrsDto newRespuesta) {
        Map<String, Object> response = new HashMap<>();
        try {
            repuestaBusiness.createRespuestaPqrs(newRespuesta);
            response.put("Status", "Success");
            response.put("data", newRespuesta);

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("data", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateRespuesta(@PathVariable int id,
                                                               @RequestBody RespuestaPqrsDto existeRespuesta) {
        Map<String, Object> response = new HashMap<>();
        try {
            repuestaBusiness.updateRespuestaPqrs(id, existeRespuesta);
            response.put("Status", "Success");
            response.put("data", existeRespuesta);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("data", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteRespuesta(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try{
            repuestaBusiness.deleteRespuestaPqrs(id);
            response.put("Status", "Success");
            response.put("data", "Eliminado su respuesta");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("data", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
