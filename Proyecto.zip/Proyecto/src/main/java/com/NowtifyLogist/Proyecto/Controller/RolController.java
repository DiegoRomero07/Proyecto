package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.RolBusiness;
import com.NowtifyLogist.Proyecto.Dto.RolDto;
import com.NowtifyLogist.Proyecto.Entity.Rol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Roles", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class RolController {
    @Autowired
    private RolBusiness rolBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllRol() {
        Map<String, Object> response = new HashMap<>();
        List<RolDto> listRoles = rolBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listRoles);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllRolById(@PathVariable int id) {
        try {
            Rol data = rolBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> CreateRol(@RequestBody RolDto newRol) {
        Map<String, Object> response = new HashMap<>();
        try {
            rolBusiness.createRol(newRol);
            response.put("Status", "Success");
            response.put("data", newRol);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> UpdateRol(@PathVariable int id,
                                                                @RequestBody RolDto existeRol) {
        Map<String, Object> response = new HashMap<>();
        try {
            rolBusiness.updaeRol(id, existeRol);
            response.put("Status", "Success");
            response.put("data", existeRol);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> DeleteRol(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            rolBusiness.deleteRol(id);
            response.put("Status", "Success");
            response.put("data", "Inventario eliminado");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
