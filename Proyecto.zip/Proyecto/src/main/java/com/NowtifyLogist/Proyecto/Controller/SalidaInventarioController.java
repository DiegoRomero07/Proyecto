package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.SalidaInventarioBusiness;
import com.NowtifyLogist.Proyecto.Dto.SalidaInventarioDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Salidas-Inventario", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class SalidaInventarioController {
    @Autowired
    private SalidaInventarioBusiness salidaBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> findAllSalida(){
        Map<String, Object> response = new HashMap<>();
        List<SalidaInventarioDto> listSalida = salidaBusiness.findAll();
        response.put("Status", "Succes");
        response.put("data", listSalida);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> findAllSalida(@PathVariable int id){
        try {
            SalidaInventarioDto data = salidaBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Succes");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createSalida(@RequestBody SalidaInventarioDto newSalida){
        Map<String, Object> response = new HashMap<>();
        try {
            salidaBusiness.createSalida(newSalida);
            response.put("Status", "Succes");
            response.put("data", newSalida);

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateSalida(@PathVariable int id,
                                                            @RequestBody SalidaInventarioDto existeSalida){
        Map<String, Object> response = new HashMap<>();
        try {
            salidaBusiness.updateSalida(id, existeSalida);
            response.put("Status", "Succes");
            response.put("data", existeSalida);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteSalida(@PathVariable int id){
        Map<String, Object> response = new HashMap<>();
        try {
            salidaBusiness.deleteSalida(id);
            response.put("Status", "Succes");
            response.put("data", "eliminado satisfactoriamente");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
