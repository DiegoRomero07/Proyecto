package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.SolicitudGarantiaBusiness;
import com.NowtifyLogist.Proyecto.Dto.SolicitudGarantiaDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Solicitudes-Garantias", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class SolicitudGarantiaController {
    @Autowired
    private SolicitudGarantiaBusiness solicitudBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllSolicitudes() {
        Map<String, Object> response = new HashMap<>();
        List<SolicitudGarantiaDto> listSolicitud = solicitudBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listSolicitud);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllSolicitudes(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            SolicitudGarantiaDto data = solicitudBusiness.findById(id);
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createSolicitudes(@RequestBody SolicitudGarantiaDto newSolicitud) {
        Map<String, Object> response = new HashMap<>();
        try {
            solicitudBusiness.createSolicitud(newSolicitud);
            response.put("Status", "Success");
            response.put("data", newSolicitud);

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateSolicitud(@PathVariable int id,
                                                               @RequestBody SolicitudGarantiaDto existeSolicitud) {
        Map<String, Object> response = new HashMap<>();
        try {
            solicitudBusiness.updateSolicitud(id, existeSolicitud);
            response.put("Status", "Success");
            response.put("data", existeSolicitud);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteSolicitud(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            solicitudBusiness.deleteSolicitud(id);
            response.put("Status", "Success");
            response.put("data", "Eliminado Satisfactoriamente");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
