package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.UsuarioBusiness;
import com.NowtifyLogist.Proyecto.Dto.UsuarioDto;
import com.NowtifyLogist.Proyecto.Entity.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Usuarios", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class UsuarioController {
    @Autowired
    private UsuarioBusiness usuarioBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllUsuarios() {
        Map<String, Object> response = new HashMap<>();
        List<UsuarioDto> listUsuarios = usuarioBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listUsuarios);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllUsuariosById(@PathVariable("id") int id) {
        try {
            Usuario data = usuarioBusiness.findById(id);
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Success");
            response.put("data", data);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> getCreateUsuario(@RequestBody UsuarioDto newUsuario) {
        Map<String, Object> response = new HashMap<>();
        try {
            usuarioBusiness.createUsuario(newUsuario);
            response.put("Status", "Success");
            response.put("data", newUsuario);

            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> getUpdateUsuario(@PathVariable("id") int id,
                                                                @RequestBody UsuarioDto existeUsuario) {
        Map<String, Object> response = new HashMap<>();
        try {
            usuarioBusiness.updateUsuario(id, existeUsuario);
            response.put("Status", "Success");
            response.put("data", existeUsuario);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> getDeleteUsuario(@PathVariable("id") int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            usuarioBusiness.deleteUsuario(id);
            response.put("Status", "Success");
            response.put("data", "Usuario eliminado");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("message", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
