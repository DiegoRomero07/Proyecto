package com.NowtifyLogist.Proyecto.Controller;

import com.NowtifyLogist.Proyecto.Business.VentaBusiness;
import com.NowtifyLogist.Proyecto.Dto.VentaDto;
import com.NowtifyLogist.Proyecto.Entity.Venta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path = "/api/Ventas", method = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
@CrossOrigin("*")
public class VentaController {
    @Autowired
    private VentaBusiness ventaBusiness;

    @GetMapping("/all")
    public ResponseEntity<Map<String, Object>> getAllVentas() {
        Map<String, Object> response = new HashMap<>();
        List<VentaDto> listVentas = ventaBusiness.findAll();
        response.put("Status", "Success");
        response.put("data", listVentas);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/all/{id}")
    public ResponseEntity<Map<String, Object>> getAllVentasById(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            Venta data = ventaBusiness.findById(id);
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("Status", "Success");
            responseData.put("data", data);

            return new ResponseEntity<>(responseData, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("data", e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/create")
    public ResponseEntity<Map<String, Object>> createVentas(@RequestBody VentaDto newVenta) {
        Map<String, Object> response = new HashMap<>();
        try {
            ventaBusiness.createVenta(newVenta);
            response.put("Status", "Success");
            response.put("data", newVenta);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("data", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/update/{id}")
    public ResponseEntity<Map<String, Object>> updateVentas(@PathVariable int id,
                                                            @RequestBody VentaDto existeVenta) {
        Map<String, Object> response = new HashMap<>();
        try {
            ventaBusiness.updateVenta(id, existeVenta);
            response.put("Status", "Success");
            response.put("data", existeVenta);

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("data", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<Map<String, Object>> deleteVentas(@PathVariable int id) {
        Map<String, Object> response = new HashMap<>();
        try {
            ventaBusiness.deleteVenta(id);
            response.put("Status", "Success");
            response.put("data", "Venta eliminada");

            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("Status", "Error");
            response.put("data", e.getMessage());

            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

