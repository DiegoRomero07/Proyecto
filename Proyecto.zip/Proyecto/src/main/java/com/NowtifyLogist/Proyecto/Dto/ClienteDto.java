package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteDto {

    private int id;
    private String nombre;
    private int Documento;
    private String apellido;
    private String email;
    private String telefono;
    private String direccion;
}
