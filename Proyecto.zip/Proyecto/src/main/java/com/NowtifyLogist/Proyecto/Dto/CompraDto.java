package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompraDto {

    private int id;
    private Date fechaCompra;
    private double totalCompra;
    private ProveedorDto idProveedor;
}
