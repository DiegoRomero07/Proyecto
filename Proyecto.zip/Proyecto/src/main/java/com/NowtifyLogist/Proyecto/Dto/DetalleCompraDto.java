package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DetalleCompraDto {

    private int id;
    private int cantidadCompra;
    private double precioUnitario;
    private CompraDto idCompra;
    private ProductoDto idProducto;
}
