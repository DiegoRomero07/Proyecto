package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DetalleVentaDto {

    private int id;
    private int cantidadVendida;
    private double precioVenta;
    private double precioUnitario;
    private double descuento;
    private VentaDto idVenta;
    private ProductoDto idProducto;
}
