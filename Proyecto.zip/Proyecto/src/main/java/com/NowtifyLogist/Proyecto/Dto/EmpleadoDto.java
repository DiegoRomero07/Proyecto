package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmpleadoDto {

    private int id;
    private String documento;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;
    private CargoDto idCargo;
}
