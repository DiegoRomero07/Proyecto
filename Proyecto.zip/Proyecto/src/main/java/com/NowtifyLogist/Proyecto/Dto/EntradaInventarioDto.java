package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EntradaInventarioDto {

    private int id;
    private int cantidadEntrada;
    private Date fechaEntrada;
    private double precioUnitario;
    private double precioTotal;
    private ProductoDto idProducto;
}
