package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EstadoPqrsDto {

    private int id;
    private String nombreEstado;
}
