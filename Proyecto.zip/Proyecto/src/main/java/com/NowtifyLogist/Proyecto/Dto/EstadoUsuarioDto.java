package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EstadoUsuarioDto {

    private int id;
    private String tipoEstado;
}
