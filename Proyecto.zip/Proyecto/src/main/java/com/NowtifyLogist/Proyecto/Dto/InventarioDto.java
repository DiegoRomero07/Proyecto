package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InventarioDto {

    private int id;
    private int cantidad;
    private Date fechaAdquisicion;
    private String estado;
    private String notas;
    private ProductoDto Referencia;
}
