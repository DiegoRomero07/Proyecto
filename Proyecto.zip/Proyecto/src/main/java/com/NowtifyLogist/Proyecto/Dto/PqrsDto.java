package com.NowtifyLogist.Proyecto.Dto;

import com.NowtifyLogist.Proyecto.Entity.Empleado;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PqrsDto {
    private int id;
    private String descripcion;
    private Date fechaCreacion;
    private String prioridad;
    private Date fechaRespuesta;
    private ClienteDto idCliente;
    private EmpleadoDto idEmpleado;
    private EstadoPqrsDto idEstadoPqrs;
    private RespuestaPqrsDto idRespuestaPqrs;
}
