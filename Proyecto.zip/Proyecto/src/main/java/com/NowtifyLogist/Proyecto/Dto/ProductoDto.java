package com.NowtifyLogist.Proyecto.Dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonPropertyOrder({"referencia", "descripcion", "medida", "diametro", "largo", "precio", "cantidad", "idCategoria", "idProveedor"})
public class ProductoDto {
    private String Referencia;
    private String descripcion;
    private Integer medida;
    private Integer diametro;
    private Integer largo;
    private int precio;
    private int cantidad;
    private CategoriaDto idCategoria;
    private ProveedorDto idProveedor;
}
