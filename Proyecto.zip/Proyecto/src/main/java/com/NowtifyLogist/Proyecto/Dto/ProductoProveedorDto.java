package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductoProveedorDto {

    private int id;
    private double precioCompra;
    private int cantidadMinima;
    private Date fechaUltimoPedido;
    private int tiempoEntrega;
    private ProductoDto idProducto;
    private ProveedorDto idProveedor;
}
