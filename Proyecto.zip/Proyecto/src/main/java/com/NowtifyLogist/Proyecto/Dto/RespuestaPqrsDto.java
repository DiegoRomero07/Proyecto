package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RespuestaPqrsDto {

    private int id;
    private Date fechaRespuesta;
    private String nombreRespuesta;
}
