package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SalidaInventarioDto {

    private int id;
    private Date fechaSalida;
    private int cantidad;
    private String motivo;
    private ProductoDto idProducto;
    private EmpleadoDto idEmpleado;
}
