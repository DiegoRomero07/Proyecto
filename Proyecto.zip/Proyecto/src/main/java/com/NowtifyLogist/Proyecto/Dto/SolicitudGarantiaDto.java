package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SolicitudGarantiaDto {

    private int id;
    private Date fechaSolicitud;
    private String descripcionProblema;
    private Date fechaSolucion;
    private String accionTomada;
    private ClienteDto idCliente;
    private ProductoDto idProducto;
    private EstadoSolicitudDto idEstadoSolicitud;
}
