package com.NowtifyLogist.Proyecto.Dto;

import com.NowtifyLogist.Proyecto.Entity.EstadoUsuario;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioDto {

    private int id;
    private String nombreUsuario;
    private String contraseña;
    private String correo;
    private Date fechaRegistro;
    private RolDto idRol;
    private EstadoUsuarioDto idEstadoUsuario;
}
