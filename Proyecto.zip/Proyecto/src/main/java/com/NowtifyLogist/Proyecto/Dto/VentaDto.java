package com.NowtifyLogist.Proyecto.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VentaDto {

    private int id;
    private Date fechaVenta;
    private Double total;
    private ClienteDto idCliente;
}
