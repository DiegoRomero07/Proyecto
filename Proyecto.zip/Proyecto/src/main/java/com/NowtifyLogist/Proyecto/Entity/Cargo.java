package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "Cargos")
@Data
@Getter
@Setter
public class Cargo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_Cargo")
    private int idCargo;

    @Column(name = "NombreCargo")
    private String nombreCargo;

    @Column(name = "Descripcion")
    private String descripcion;

    @JsonBackReference
    @OneToMany(mappedBy = "cargo")
    private List<Empleado> empleados;

}
