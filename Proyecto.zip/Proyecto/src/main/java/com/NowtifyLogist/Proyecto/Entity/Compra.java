package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "Compras")
@Data
@Setter
@Getter
public class Compra implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_Compra")
    private int idCompra;

    @Column(name = "FechaCompra")
    private Date fechaCompra;

    @Column(name = "TotalCompra")
    private double totalCompra;

    @ManyToOne
    @JoinColumn(name = "Proveedor")
    private Proveedor proveedor;

    @JsonIgnore
    @OneToMany(mappedBy = "compra")
    private List<DetalleCompra> detalleCompra;
}
