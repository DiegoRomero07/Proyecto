package com.NowtifyLogist.Proyecto.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "DetallesCompras")
@Data
@Setter
@Getter
public class DetalleCompra {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_DetalleCompra")
    private int idDetalleCompra;

    @Column(name = "CantidadCompra")
    private int cantidadCompra;

    @Column(name = "PrecioUnitario")
    private double precioUnitario;

    @ManyToOne
    @JoinColumn(name = "idCompra")
    private Compra compra;

    @ManyToOne
    @JoinColumn(name = "Referencia")
    private Producto producto;
}
