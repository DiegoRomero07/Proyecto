package com.NowtifyLogist.Proyecto.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "DetallesVentas")
@Data
@Setter
@Getter
public class DetalleVenta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_DetalleVenta")
    private int idDetalleVenta;

    @Column(name = "CantidadVendida")
    private int cantidadVendida;

    @Column(name = "PrecioVenta")
    private double precioVenta;

    @Column(name = "PrecioUnitario")
    private double precioUnitario;

    @Column(name = "Descuento")
    private double descuento;

    @ManyToOne
    @JoinColumn(name = "idVenta")
    private Venta venta;

    @ManyToOne
    @JoinColumn(name = "Referencia")
    private Producto producto;

}
