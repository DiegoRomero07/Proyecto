package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "Empleados")
@Data
@Setter
@Getter
public class Empleado {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_Empleado")
    private int idEmpleado;

    @Column(name = "Documento")
    private String documento;

    @Column(name = "Nombres")
    private String nombres;

    @Column(name = "Apellidos")
    private String apellidos;

    @Column(name = "Email")
    private String email;

    @Column(name = "Telefono")
    private String telefono;

    @ManyToOne
    @JoinColumn(name = "Cargo")
    private Cargo cargo;

    @JsonBackReference
    @OneToMany(mappedBy = "empleado")
    private List<SalidaInventario> salidaInventarios;
}
