package com.NowtifyLogist.Proyecto.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "EntradaInventario")
@Data
@Setter
@Getter
public class EntradaInventario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_EntradaInventario")
    private int idEntradaInventario;

    @Column(name = "CantidadEntrada")
    private int cantidadEntrada;

    @Column(name = "FechaEntrada")
    private Date fechaEntrada;

    @Column(name = "PrecioUnitario")
    private double precioUnitario;

    @Column(name = "Total")
    private double total;

    @ManyToOne
    @JoinColumn(name = "Referencia")
    private Producto producto;
}
