package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "EstadosPqrs")
@Data
@Setter
@Getter
public class EstadoPqrs {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_EstadoPqrs")
    private int idEstadoPqrs;

    @Column(name = "NombreEstado")
    private String nombreEstado;

    @JsonBackReference
    @OneToMany(mappedBy = "estadoPqrs")
    private List<Pqrs> pqrs;
}
