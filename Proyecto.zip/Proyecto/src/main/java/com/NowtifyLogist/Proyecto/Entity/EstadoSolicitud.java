package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "EstadoSolicitudes")
@Data
@Setter
@Getter
public class EstadoSolicitud {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_EstadoSolicitud")
    private int idEstadoSolicitud;

    @Column(name = "NombreEstado")
    private String nombreEstado;

    @JsonBackReference
    @OneToMany(mappedBy = "estadoSolicitud")
    private List<SolicitudGarantia> solicitudGarantias;
}
