package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "EstadoUsuarios")
@Data
@Setter
@Getter
public class EstadoUsuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_EstadoUsuario")
    private int idEstadoUsuario;

    @Column(name = "TipoEstado")
    private String tipoEstado;

    @JsonBackReference
    @OneToMany(mappedBy = "estadoUsuario")
    private List<Usuario> usuarios;
}
