package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "Inventario")
@Data
@Setter
@Getter
public class Inventario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_Inventario")
    private int idInventario;

    @Column(name = "Cantidad")
    private int cantidad;

    @Column(name = "FechaAdquisicion")
    private Date fechaAdquisicion;

    @Column(name = "Estado")
    private String estado;

    @Column(name = "Notas")
    private String notas;

    @ManyToOne
    @JoinColumn(name = "Referencia")
    private Producto producto;

}
