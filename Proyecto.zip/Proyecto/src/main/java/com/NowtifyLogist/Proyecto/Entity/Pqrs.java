package com.NowtifyLogist.Proyecto.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "Pqrs")
@Data
@Setter
@Getter
public class Pqrs {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_Pqrs")
    private int id;

    @Column(name = "Descripcion")
    private String descripcion;

    @Column(name = "FechaCreacion")
    private Date fechaCreacion;

    @Column(name = "Prioridad")
    private String prioridad;

    @Column(name = "FechaRespuesta")
    private Date fechaRespuesta;

    @ManyToOne
    @JoinColumn(name = "idCliente")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "idEmpleado")
    private Empleado empleado;

    @ManyToOne
    @JoinColumn(name = "idEstado")
    private EstadoPqrs estadoPqrs;

    @ManyToOne
    @JoinColumn(name = "idRespuestaPqrs")
    private RespuestaPqrs respuestaPqrs;
}
