package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "Producto")
@Data
@Setter
@Getter
public class Producto {
    @Id
    @Column(name = "Referencia")
    private String Referencia;

    @Column(name = "Descripcion")
    private String descripcion;

    @Column(name = "Medida")
    private Integer medida;

    @Column(name = "diametro")
    private Integer diametro;

    @Column(name = "largo")
    private Integer largo;

    @Column(name = "Precio")
    private int precio;

    @Column(name = "Cantidad")
    private int cantidad;

    @JsonBackReference
    @OneToMany(mappedBy = "producto")
    private List<Inventario> inventarios;

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "Categoria")
    private Categoria categoria;

    @JsonBackReference
    @OneToMany(mappedBy = "producto")
    private List<ProductoProveedor> productoProveedores;

    @JsonBackReference
    @OneToMany(mappedBy = "producto")
    private List<DetalleVenta> detalleVentas;

    @JsonBackReference
    @OneToMany(mappedBy = "producto")
    private List<DetalleCompra> detalleCompras;

    @JsonBackReference
    @OneToMany(mappedBy = "producto")
    private List<EntradaInventario> entradaInventarios;

    @JsonBackReference
    @OneToMany(mappedBy = "producto")
    private List<SalidaInventario> salidaInventarios;

    @JsonManagedReference
    @ManyToOne
    @JoinColumn(name = "proveedor")
    private Proveedor proveedor;

    @JsonBackReference
    @OneToMany(mappedBy = "producto")
    private List<SolicitudGarantia> solicitudGarantias;
}
