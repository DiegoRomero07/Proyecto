package com.NowtifyLogist.Proyecto.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "ProductoProveedores")
@Data
@Setter
@Getter
public class ProductoProveedor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ProductoProveedor")
    private int idProductoProveedor;

    @Column(name = "PrecioCompra")
    private double precioCompra;

    @Column(name = "CantidadMinima")
    private int cantidadMinima;

    @Column(name = "FechaUltimoPedido")
    private Date fechaUltimoPedido;

    @Column(name = "TiempoEntrega")
    private int tiempoEntrega;

    @ManyToOne
    @JoinColumn(name = "Referencia")
    private Producto producto;

    @ManyToOne
    @JoinColumn(name = "idProveedor")
    private Proveedor proveedor;
}
