package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "RespuestasPqrs")
@Data
@Setter
@Getter
public class RespuestaPqrs {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_RespuestaPqrs")
    private int idRespuestaPqrs;

    @Column(name = "FechaRespuesta")
    private Date fechaRespuesta;

    @Column(name = "NombreRespuesta")
    private String nombreRespuesta;

    @JsonBackReference
    @OneToMany(mappedBy = "respuestaPqrs")
    private List<Pqrs> pqrs;
}
