package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "Roles")
@Data
@Setter
@Getter
public class Rol {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_Rol")
    private int idRol;

    @Column(name = "NombreRol")
    private String nombreRol;

    @JsonBackReference
    @OneToMany(mappedBy = "rol")
    private List<Usuario> usuarios;
}
