package com.NowtifyLogist.Proyecto.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "SalidasInventario")
@Data
@Setter
@Getter
public class SalidaInventario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_SalidaInventario")
    private int idSalidaInventario;

    @Column(name = "FechaSalida")
    private Date fechaSalida;

    @Column(name = "Cantidad")
    private int cantidad;

    @Column(name = "Motivo")
    private String motivo;

    @ManyToOne
    @JoinColumn(name = "Referencia")
    private Producto producto;

    @ManyToOne
    @JoinColumn(name = "Empleado")
    private Empleado empleado;
}
