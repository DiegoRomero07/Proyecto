package com.NowtifyLogist.Proyecto.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "SolicitudesGarantias")
@Data
@Setter
@Getter
public class SolicitudGarantia {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_SolicitudGarantia")
    private int idSolicitudGarantia;

    @Column(name = "FechaSolicitud")
    private Date fechaSolicitud;

    @Column(name = "DescripcionProblema")
    private String descripcionProblema;

    @Column(name = "FechaSolucion")
    private Date fechaSolucion;

    @Column(name = "AccionTomada")
    private String accionTomada;

    @ManyToOne
    @JoinColumn(name = "idCliente")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "Referencia")
    private Producto producto;

    @ManyToOne
    @JoinColumn(name = "EstadoSolicitud")
    private EstadoSolicitud estadoSolicitud;
}
