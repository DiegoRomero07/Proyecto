package com.NowtifyLogist.Proyecto.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "Usuarios")
@Data
@Setter
@Getter
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_Usuario")
    private int idUsuario;

    @Column(name = "NombreUsuario")
    private String nombreUsuario;

    @Column(name = "Contraseña")
    private String contrasena;

    @Column(name = "Correo")
    private String correo;

    @Column(name = "FechaRegistro")
    private Date fechaRegistro;

    @ManyToOne
    @JoinColumn(name = "idRol")
    private Rol rol;

    @ManyToOne
    @JoinColumn(name = "idEstadoUsuario")
    private EstadoUsuario estadoUsuario;
}
