package com.NowtifyLogist.Proyecto.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Entity
@Table(name = "Ventas")
@Data
@Setter
@Getter
public class Venta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_Venta")
    private int idVenta;

    @Column(name = "FechaVenta")
    private Date fechaVenta;

    @Column(name = "Total")
    private double total;

    @JsonBackReference
    @OneToMany(mappedBy = "venta")
    private List<DetalleVenta> detalleVentas;

    @ManyToOne
    @JoinColumn(name = "idCliente")
    private Cliente cliente;
}
