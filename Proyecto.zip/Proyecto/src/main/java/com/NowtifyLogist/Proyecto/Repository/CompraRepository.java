package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.Compra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CompraRepository extends JpaRepository<Compra, Integer> {
    @Query(value = "select c from Compra c where c.idCompra =:idCompra")
    public Compra findById(int idCompra);
}
