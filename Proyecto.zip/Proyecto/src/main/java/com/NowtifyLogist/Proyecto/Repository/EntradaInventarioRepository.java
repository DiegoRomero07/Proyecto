package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.EntradaInventario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface EntradaInventarioRepository extends JpaRepository<EntradaInventario, Integer> {
    @Query(value = "select e from EntradaInventario e where e.idEntradaInventario =:idEntradaInventario")
    public EntradaInventario findById(int idEntradaInventario);
}
