package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.EstadoPqrs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface EstadoPqrsRepository extends JpaRepository<EstadoPqrs, Integer> {
    @Query(value = "select e from EstadoPqrs e where e.idEstadoPqrs =:idEstadoPqrs")
    public EstadoPqrs findById(int idEstadoPqrs);
}
