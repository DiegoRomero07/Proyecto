package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.EstadoSolicitud;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface EstadoSolicitudRepository extends JpaRepository<EstadoSolicitud, Integer> {
    @Query(value = "select e from EstadoSolicitud e where e.idEstadoSolicitud =:idEstadoSolicitud")
    public EstadoSolicitud findById(int idEstadoSolicitud);
}
