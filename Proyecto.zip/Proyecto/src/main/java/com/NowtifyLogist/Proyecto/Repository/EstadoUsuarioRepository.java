package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.EstadoUsuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface EstadoUsuarioRepository extends JpaRepository<EstadoUsuario, Integer> {
    @Query(value = "select e from EstadoUsuario e where e.idEstadoUsuario =:idEstadoUsuario")
    public EstadoUsuario findById(int idEstadoUsuario);
}
