package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.Pqrs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PqrsRepository extends JpaRepository<Pqrs, Integer> {
    @Query(value = "select p from Pqrs p where p.id =:id")
    public Pqrs findById(int id);
}
