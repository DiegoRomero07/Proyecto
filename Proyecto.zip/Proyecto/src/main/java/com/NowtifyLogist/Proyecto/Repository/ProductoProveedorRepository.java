package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.ProductoProveedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductoProveedorRepository extends JpaRepository<ProductoProveedor, Integer> {
    @Query(value = "select p from ProductoProveedor p where p.idProductoProveedor =:idProductoProveedor")
    public ProductoProveedor findById(int id);
}
