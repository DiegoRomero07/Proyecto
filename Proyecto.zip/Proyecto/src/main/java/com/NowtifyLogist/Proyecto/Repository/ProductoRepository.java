package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, String> {
    @Query(value = "select p from Producto p where p.Referencia =:Referencia")
    public Optional<Producto> findById(String Referencia);
}
