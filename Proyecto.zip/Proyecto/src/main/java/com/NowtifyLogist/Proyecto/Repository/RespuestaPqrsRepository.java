package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.RespuestaPqrs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RespuestaPqrsRepository extends JpaRepository<RespuestaPqrs, Integer> {
    @Query(value = "select r from RespuestaPqrs r where r.idRespuestaPqrs =:idRespuestaPqrs")
    public RespuestaPqrs findById(int idRespuestaPqrs);
}
