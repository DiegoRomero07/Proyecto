package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.SalidaInventario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SalidaInventarioRepository extends JpaRepository<SalidaInventario, Integer> {
    @Query(value = "select s from SalidaInventario s where s.idSalidaInventario =:idSalidaInventario")
    public SalidaInventario findById(int idSalidaInventario);
}
