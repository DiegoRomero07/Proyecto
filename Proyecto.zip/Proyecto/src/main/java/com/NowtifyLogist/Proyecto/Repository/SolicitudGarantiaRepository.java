package com.NowtifyLogist.Proyecto.Repository;

import com.NowtifyLogist.Proyecto.Entity.SolicitudGarantia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SolicitudGarantiaRepository extends JpaRepository<SolicitudGarantia, Integer> {
    @Query(value = "select s from SolicitudGarantia s where s.idSolicitudGarantia =:idSolicitudGarantia")
    public SolicitudGarantia findById(int idSolicitudGarantia);
}
