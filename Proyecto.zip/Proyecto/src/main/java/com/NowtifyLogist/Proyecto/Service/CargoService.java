package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Cargo;

import java.util.List;

public interface CargoService {

    List<Cargo> findAll();
    Cargo findById(int id);
    void create(Cargo cargo);
    void update(Cargo cargo);
    void delete(Cargo cargo);

}
