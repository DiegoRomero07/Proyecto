package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Categoria;

import java.util.List;

public interface CategoriaService {

    List<Categoria> findAll();
    Categoria findById(int id);
    void save(Categoria categoria);
    void update(Categoria categoria);
    void delete(Categoria categoria);

}
