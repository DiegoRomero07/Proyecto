package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Cliente;

import java.util.List;

public interface ClienteService {

    List<Cliente> findAll();
    Cliente findById(int id);
    void save(Cliente cliente);
    void update(Cliente cliente);
    void delete(Cliente cliente);
}
