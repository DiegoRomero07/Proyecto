package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Compra;

import java.util.List;

public interface CompraService {

    List<Compra> findAll();
    Compra findById(int id);
    void save(Compra compra);
    void update(Compra compra);
    void delete(Compra compra);
}
