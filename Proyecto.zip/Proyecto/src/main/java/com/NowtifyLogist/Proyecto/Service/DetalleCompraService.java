package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.DetalleCompra;

import java.util.List;

public interface DetalleCompraService {

    List<DetalleCompra> findAll();
    DetalleCompra findById(int id);
    void save(DetalleCompra detalleCompra);
    void update(DetalleCompra detalleCompra);
    void delete(DetalleCompra detalleCompra);
}
