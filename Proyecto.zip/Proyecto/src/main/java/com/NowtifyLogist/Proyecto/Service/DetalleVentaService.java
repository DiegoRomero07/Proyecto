package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.DetalleVenta;

import java.util.List;

public interface DetalleVentaService {

    List<DetalleVenta> findAll();
    DetalleVenta findById(int id);
    void save(DetalleVenta detalleVenta);
    void update(DetalleVenta detalleVenta);
    void delete(DetalleVenta detalleVenta);
}
