package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Empleado;

import java.util.List;

public interface EmpleadoService {

    List<Empleado> findAll();
    Empleado findById(int id);
    void save(Empleado empleado);
    void update(Empleado empleado);
    void delete(Empleado empleado);
}
