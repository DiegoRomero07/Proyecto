package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.EntradaInventario;

import java.util.List;

public interface EntradaInventarioService {

    List<EntradaInventario> findAll();
    EntradaInventario findById(int id);
    void save(EntradaInventario entradaInventario);
    void update(EntradaInventario entradaInventario);
    void delete(EntradaInventario entradaInventario);
}
