package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.EstadoPqrs;

import java.util.List;

public interface EstadoPqrsService {

    List<EstadoPqrs> findAll();
    EstadoPqrs findById(int id);
    void save(EstadoPqrs estadoPqrs);
    void update(EstadoPqrs estadoPqrs);
    void delete(EstadoPqrs estadoPqrs);
}
