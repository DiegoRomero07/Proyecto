package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.EstadoSolicitud;

import java.util.List;

public interface EstadoSolicitudService {

    List<EstadoSolicitud> findAll();
    EstadoSolicitud findById(int id);
    void save(EstadoSolicitud estadoSolicitud);
    void update(EstadoSolicitud estadoSolicitud);
    void delete(EstadoSolicitud estadoSolicitud);
}
