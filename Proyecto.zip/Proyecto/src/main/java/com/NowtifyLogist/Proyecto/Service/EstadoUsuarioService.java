package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.EstadoUsuario;

import java.util.List;

public interface EstadoUsuarioService {

    List<EstadoUsuario> findAll();
    EstadoUsuario findById(int id);
    void save(EstadoUsuario estadoUsuario);
    void update(EstadoUsuario estadoUsuario);
    void delete(EstadoUsuario estadoUsuario);
}
