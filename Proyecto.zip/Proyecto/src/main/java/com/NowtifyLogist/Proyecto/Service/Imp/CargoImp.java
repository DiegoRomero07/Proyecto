package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Cargo;
import com.NowtifyLogist.Proyecto.Repository.CargoRepository;
import com.NowtifyLogist.Proyecto.Service.CargoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CargoImp implements CargoService {

    @Autowired
    private CargoRepository cargoRepository;

    @Override
    public List<Cargo> findAll() {
        return this.cargoRepository.findAll();
    }

    @Override
    public Cargo findById(int id) {
        return this.cargoRepository.findById(id);
    }

    @Override
    public void create(Cargo cargo) {
        this.cargoRepository.save(cargo);
    }

    @Override
    public void update(Cargo cargo) {
        this.cargoRepository.save(cargo);
    }

    @Override
    public void delete(Cargo cargo) {
        this.cargoRepository.delete(cargo);
    }
}
