package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Categoria;
import com.NowtifyLogist.Proyecto.Repository.CategoriaRepository;
import com.NowtifyLogist.Proyecto.Service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaImp implements CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Override
    public List<Categoria> findAll() {
        return this.categoriaRepository.findAll();
    }

    @Override
    public Categoria findById(int id) {
        return this.categoriaRepository.findById(id);
    }

    @Override
    public void save(Categoria categoria) {
        this.categoriaRepository.save(categoria);
    }

    @Override
    public void update(Categoria categoria) {
        this.categoriaRepository.save(categoria);
    }

    @Override
    public void delete(Categoria categoria) {
        this.categoriaRepository.delete(categoria);
    }
}
