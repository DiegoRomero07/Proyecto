package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Cliente;
import com.NowtifyLogist.Proyecto.Repository.ClienteRepository;
import com.NowtifyLogist.Proyecto.Service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClienteImp implements ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Override
    public List<Cliente> findAll() {
        return this.clienteRepository.findAll();
    }

    @Override
    public Cliente findById(int id) {
        return this.clienteRepository.findById(id);
    }

    @Override
    public void save(Cliente cliente) {
        this.clienteRepository.save(cliente);
    }

    @Override
    public void update(Cliente cliente) {
        this.clienteRepository.save(cliente);
    }

    @Override
    public void delete(Cliente cliente) {
        this.clienteRepository.delete(cliente);
    }
}
