package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Compra;
import com.NowtifyLogist.Proyecto.Repository.CompraRepository;
import com.NowtifyLogist.Proyecto.Service.CompraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompraImp implements CompraService {

    @Autowired
    private CompraRepository compraRepository;

    @Override
    public List<Compra> findAll() {
        return this.compraRepository.findAll();
    }

    @Override
    public Compra findById(int id) {
        return this.compraRepository.findById(id);
    }

    @Override
    public void save(Compra compra) {
        this.compraRepository.save(compra);
    }

    @Override
    public void update(Compra compra) {
        this.compraRepository.save(compra);
    }

    @Override
    public void delete(Compra compra) {
        this.compraRepository.delete(compra);
    }
}
