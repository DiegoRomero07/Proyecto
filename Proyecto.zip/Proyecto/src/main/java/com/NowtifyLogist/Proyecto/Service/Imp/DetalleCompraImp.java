package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.DetalleCompra;
import com.NowtifyLogist.Proyecto.Repository.DetalleCompraRepository;
import com.NowtifyLogist.Proyecto.Service.DetalleCompraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DetalleCompraImp implements DetalleCompraService {

    @Autowired
    private DetalleCompraRepository detalleCompraRepository;

    @Override
    public List<DetalleCompra> findAll() {
        return this.detalleCompraRepository.findAll();
    }

    @Override
    public DetalleCompra findById(int id) {
        return this.detalleCompraRepository.findById(id);
    }

    @Override
    public void save(DetalleCompra detalleCompra) {
        this.detalleCompraRepository.save(detalleCompra);
    }

    @Override
    public void update(DetalleCompra detalleCompra) {
        this.detalleCompraRepository.save(detalleCompra);
    }

    @Override
    public void delete(DetalleCompra detalleCompra) {
        this.detalleCompraRepository.delete(detalleCompra);
    }
}
