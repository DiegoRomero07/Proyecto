package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.DetalleVenta;
import com.NowtifyLogist.Proyecto.Repository.DetalleVentaRepository;
import com.NowtifyLogist.Proyecto.Service.DetalleVentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DetalleVentaImp implements DetalleVentaService {

    @Autowired
    private DetalleVentaRepository detalleVentaRepository;

    @Override
    public List<DetalleVenta> findAll() {
        return this.detalleVentaRepository.findAll();
    }

    @Override
    public DetalleVenta findById(int id) {
        return this.detalleVentaRepository.findById(id);
    }

    @Override
    public void save(DetalleVenta detalleVenta) {
        this.detalleVentaRepository.save(detalleVenta);
    }

    @Override
    public void update(DetalleVenta detalleVenta) {
        this.detalleVentaRepository.save(detalleVenta);
    }

    @Override
    public void delete(DetalleVenta detalleVenta) {
        this.detalleVentaRepository.delete(detalleVenta);
    }
}
