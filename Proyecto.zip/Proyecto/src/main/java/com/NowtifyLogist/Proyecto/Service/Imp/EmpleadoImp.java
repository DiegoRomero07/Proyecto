package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Empleado;
import com.NowtifyLogist.Proyecto.Repository.EmpleadoRepository;
import com.NowtifyLogist.Proyecto.Service.EmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmpleadoImp implements EmpleadoService {

    @Autowired
    private EmpleadoRepository empleadoRepository;

    @Override
    public List<Empleado> findAll() {
        return this.empleadoRepository.findAll();
    }

    @Override
    public Empleado findById(int id) {
        return this.empleadoRepository.findById(id);
    }

    @Override
    public void save(Empleado empleado) {
        this.empleadoRepository.save(empleado);
    }

    @Override
    public void update(Empleado empleado) {
        this.empleadoRepository.save(empleado);
    }

    @Override
    public void delete(Empleado empleado) {
        this.empleadoRepository.delete(empleado);
    }
}
