package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.EntradaInventario;
import com.NowtifyLogist.Proyecto.Service.EntradaInventarioService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EntradaInventarioImp implements EntradaInventarioService {
    @Override
    public List<EntradaInventario> findAll() {
        return List.of();
    }

    @Override
    public EntradaInventario findById(int id) {
        return null;
    }

    @Override
    public void save(EntradaInventario entradaInventario) {

    }

    @Override
    public void update(EntradaInventario entradaInventario) {

    }

    @Override
    public void delete(EntradaInventario entradaInventario) {

    }
}
