package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.EstadoPqrs;
import com.NowtifyLogist.Proyecto.Service.EstadoPqrsService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EstadoPqrsImp implements EstadoPqrsService {
    @Override
    public List<EstadoPqrs> findAll() {
        return List.of();
    }

    @Override
    public EstadoPqrs findById(int id) {
        return null;
    }

    @Override
    public void save(EstadoPqrs estadoPqrs) {

    }

    @Override
    public void update(EstadoPqrs estadoPqrs) {

    }

    @Override
    public void delete(EstadoPqrs estadoPqrs) {

    }
}
