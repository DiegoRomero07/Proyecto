package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.EstadoSolicitud;
import com.NowtifyLogist.Proyecto.Service.EstadoSolicitudService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EstadoSolicitudImp implements EstadoSolicitudService {
    @Override
    public List<EstadoSolicitud> findAll() {
        return List.of();
    }

    @Override
    public EstadoSolicitud findById(int id) {
        return null;
    }

    @Override
    public void save(EstadoSolicitud estadoSolicitud) {

    }

    @Override
    public void update(EstadoSolicitud estadoSolicitud) {

    }

    @Override
    public void delete(EstadoSolicitud estadoSolicitud) {

    }
}
