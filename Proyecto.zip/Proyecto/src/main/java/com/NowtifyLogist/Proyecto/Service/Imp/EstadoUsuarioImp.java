package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.EstadoUsuario;
import com.NowtifyLogist.Proyecto.Service.EstadoUsuarioService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EstadoUsuarioImp implements EstadoUsuarioService {
    @Override
    public List<EstadoUsuario> findAll() {
        return List.of();
    }

    @Override
    public EstadoUsuario findById(int id) {
        return null;
    }

    @Override
    public void save(EstadoUsuario estadoUsuario) {

    }

    @Override
    public void update(EstadoUsuario estadoUsuario) {

    }

    @Override
    public void delete(EstadoUsuario estadoUsuario) {

    }
}
