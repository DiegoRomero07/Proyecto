package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Inventario;
import com.NowtifyLogist.Proyecto.Service.InventarioService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventarioImp implements InventarioService {
    @Override
    public List<Inventario> findAll() {
        return List.of();
    }

    @Override
    public Inventario findById(int id) {
        return null;
    }

    @Override
    public void save(Inventario inventario) {

    }

    @Override
    public void update(Inventario inventario) {

    }

    @Override
    public void delete(Inventario inventario) {

    }
}
