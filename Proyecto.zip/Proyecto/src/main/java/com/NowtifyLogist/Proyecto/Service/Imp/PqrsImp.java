package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Pqrs;
import com.NowtifyLogist.Proyecto.Repository.PqrsRepository;
import com.NowtifyLogist.Proyecto.Service.PqrsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PqrsImp implements PqrsService {

    @Autowired
    private PqrsRepository pqrsRepository;

    @Override
    public List<Pqrs> findAll() {
        return this.pqrsRepository.findAll();
    }

    @Override
    public Pqrs findById(int id) {
        return this.pqrsRepository.findById(id);
    }

    @Override
    public void save(Pqrs pqrs) {
        this.pqrsRepository.save(pqrs);
    }

    @Override
    public void update(Pqrs pqrs) {
        this.pqrsRepository.save(pqrs);
    }

    @Override
    public void delete(Pqrs pqrs) {
        this.pqrsRepository.delete(pqrs);
    }
}
