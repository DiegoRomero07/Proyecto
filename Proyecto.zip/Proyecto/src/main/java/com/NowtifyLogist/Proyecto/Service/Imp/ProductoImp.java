package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Producto;
import com.NowtifyLogist.Proyecto.Repository.ProductoRepository;
import com.NowtifyLogist.Proyecto.Service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductoImp implements ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    @Override
    public List<Producto> findAll() {
        return this.productoRepository.findAll();
    }

    @Override
    public Optional<Producto> findById(String Referencia) {
        return this.productoRepository.findById(Referencia);
    }

    @Override
    public void save(Producto producto) {
        this.productoRepository.save(producto);
    }

    @Override
    public void update(Producto producto) {
        this.productoRepository.save(producto);
    }

    @Override
    public void delete(Producto producto) {
        this.productoRepository.delete(producto);
    }
}
