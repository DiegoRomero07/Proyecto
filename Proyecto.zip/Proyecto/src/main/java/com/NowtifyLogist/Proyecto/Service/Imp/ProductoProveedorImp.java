package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.ProductoProveedor;
import com.NowtifyLogist.Proyecto.Service.ProductoProveedorService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoProveedorImp implements ProductoProveedorService {
    @Override
    public List<ProductoProveedor> findAll() {
        return List.of();
    }

    @Override
    public ProductoProveedor findById(int id) {
        return null;
    }

    @Override
    public void save(ProductoProveedor productoProveedor) {

    }

    @Override
    public void update(ProductoProveedor productoProveedor) {

    }

    @Override
    public void delete(ProductoProveedor productoProveedor) {

    }
}
