package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Proveedor;
import com.NowtifyLogist.Proyecto.Repository.ProveedorRepository;
import com.NowtifyLogist.Proyecto.Service.ProveedorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProveedorImp implements ProveedorService {

    @Autowired
    private ProveedorRepository proveedorRepository;

    @Override
    public List<Proveedor> findAll() {
        return this.proveedorRepository.findAll();
    }

    @Override
    public Proveedor findById(int id) {
        return this.proveedorRepository.findById(id);
    }

    @Override
    public void save(Proveedor proveedor) {
        this.proveedorRepository.save(proveedor);
    }

    @Override
    public void update(Proveedor proveedor) {

    }

    @Override
    public void delete(Proveedor proveedor) {

    }
}
