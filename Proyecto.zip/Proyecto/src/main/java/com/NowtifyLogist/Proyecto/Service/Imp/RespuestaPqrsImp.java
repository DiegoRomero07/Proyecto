package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.RespuestaPqrs;
import com.NowtifyLogist.Proyecto.Repository.RespuestaPqrsRepository;
import com.NowtifyLogist.Proyecto.Service.RespuestaPqrsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RespuestaPqrsImp implements RespuestaPqrsService{

    @Autowired
    private RespuestaPqrsRepository respuestaPqrsRepository;

    @Override
    public List<RespuestaPqrs> findAll() {
        return this.respuestaPqrsRepository.findAll();
    }

    @Override
    public RespuestaPqrs findById(int id) {
        return this.respuestaPqrsRepository.findById(id);
    }

    @Override
    public void save(RespuestaPqrs respuestaPqrs) {
        this.respuestaPqrsRepository.save(respuestaPqrs);
    }

    @Override
    public void update(RespuestaPqrs respuestaPqrs) {
        this.respuestaPqrsRepository.save(respuestaPqrs);
    }

    @Override
    public void delete(RespuestaPqrs respuestaPqrs) {
        this.respuestaPqrsRepository.delete(respuestaPqrs);
    }
}
