package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Rol;
import com.NowtifyLogist.Proyecto.Repository.RolRepository;
import com.NowtifyLogist.Proyecto.Service.RolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RolImp implements RolService {

    @Autowired
    private RolRepository rolRepository;

    @Override
    public List<Rol> findAll() {
        return this.rolRepository.findAll();
    }

    @Override
    public Rol findById(int id) {
        return this.rolRepository.findById(id);
    }

    @Override
    public void save(Rol rol) {
        this.rolRepository.save(rol);
    }

    @Override
    public void update(Rol rol) {
        this.rolRepository.save(rol);
    }

    @Override
    public void delete(Rol rol) {
        this.rolRepository.delete(rol);
    }
}
