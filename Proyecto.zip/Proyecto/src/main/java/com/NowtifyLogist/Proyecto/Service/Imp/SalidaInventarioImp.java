package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.SalidaInventario;
import com.NowtifyLogist.Proyecto.Repository.SalidaInventarioRepository;
import com.NowtifyLogist.Proyecto.Service.SalidaInventarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SalidaInventarioImp implements SalidaInventarioService{

    @Autowired
    private SalidaInventarioRepository salidaInventarioRepository;

    @Override
    public List<SalidaInventario> findAll() {
        return this.salidaInventarioRepository.findAll();
    }

    @Override
    public SalidaInventario findById(int id) {
        return this.salidaInventarioRepository.findById(id);
    }

    @Override
    public void save(SalidaInventario salidaInventario) {
        this.salidaInventarioRepository.save(salidaInventario);
    }

    @Override
    public void update(SalidaInventario salidaInventario) {
        this.salidaInventarioRepository.save(salidaInventario);
    }

    @Override
    public void delete(SalidaInventario salidaInventario) {
        this.salidaInventarioRepository.delete(salidaInventario);
    }
}
