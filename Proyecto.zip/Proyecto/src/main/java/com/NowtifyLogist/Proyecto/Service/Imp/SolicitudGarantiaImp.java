package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.SolicitudGarantia;
import com.NowtifyLogist.Proyecto.Repository.SolicitudGarantiaRepository;
import com.NowtifyLogist.Proyecto.Service.SolicitudGarantiaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SolicitudGarantiaImp implements SolicitudGarantiaService {

    @Autowired
    private SolicitudGarantiaRepository solicitudGarantiaRepository;

    @Override
    public List<SolicitudGarantia> findAll() {
        return this.solicitudGarantiaRepository.findAll();
    }

    @Override
    public SolicitudGarantia findById(int id) {
        return this.solicitudGarantiaRepository.findById(id);
    }

    @Override
    public void save(SolicitudGarantia solicitudGarantia) {
        this.solicitudGarantiaRepository.save(solicitudGarantia);
    }

    @Override
    public void update(SolicitudGarantia solicitudGarantia) {
        this.solicitudGarantiaRepository.save(solicitudGarantia);
    }

    @Override
    public void delete(SolicitudGarantia solicitudGarantia) {
        this.solicitudGarantiaRepository.delete(solicitudGarantia);
    }
}
