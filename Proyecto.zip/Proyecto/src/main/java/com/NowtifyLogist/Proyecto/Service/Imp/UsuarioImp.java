package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Usuario;
import com.NowtifyLogist.Proyecto.Repository.UsuarioRepository;
import com.NowtifyLogist.Proyecto.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioImp implements UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public List<Usuario> findAll() {
        return this.usuarioRepository.findAll();
    }

    @Override
    public Usuario findById(int id) {
        return this.usuarioRepository.findById(id);
    }

    @Override
    public void save(Usuario usuario) {
        this.usuarioRepository.save(usuario);
    }

    @Override
    public void update(Usuario usuario) {
        this.usuarioRepository.save(usuario);
    }

    @Override
    public void delete(Usuario usuario) {
        this.usuarioRepository.delete(usuario);
    }
}
