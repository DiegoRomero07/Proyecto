package com.NowtifyLogist.Proyecto.Service.Imp;

import com.NowtifyLogist.Proyecto.Entity.Venta;
import com.NowtifyLogist.Proyecto.Repository.VentaRepository;
import com.NowtifyLogist.Proyecto.Service.VentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VentaImp implements VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    @Override
    public List<Venta> findAll() {
        return this.ventaRepository.findAll();
    }

    @Override
    public Venta findById(int id) {
        return this.ventaRepository.findById(id);
    }

    @Override
    public void save(Venta venta) {
        this.ventaRepository.save(venta);
    }

    @Override
    public void update(Venta venta) {
        this.ventaRepository.save(venta);
    }

    @Override
    public void delete(Venta venta) {
        this.ventaRepository.delete(venta);
    }
}
