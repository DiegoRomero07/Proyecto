package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Inventario;

import java.util.List;

public interface InventarioService {

    List<Inventario> findAll();
    Inventario findById(int id);
    void save(Inventario inventario);
    void update(Inventario inventario);
    void delete(Inventario inventario);
}
