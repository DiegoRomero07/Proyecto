package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Pqrs;

import java.util.List;

public interface PqrsService {

    List<Pqrs> findAll();
    Pqrs findById(int id);
    void save(Pqrs pqrs);
    void update(Pqrs pqrs);
    void delete(Pqrs pqrs);
}
