package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.ProductoProveedor;

import java.util.List;

public interface ProductoProveedorService {

    List<ProductoProveedor> findAll();
    ProductoProveedor findById(int id);
    void save(ProductoProveedor productoProveedor);
    void update(ProductoProveedor productoProveedor);
    void delete(ProductoProveedor productoProveedor);
}
