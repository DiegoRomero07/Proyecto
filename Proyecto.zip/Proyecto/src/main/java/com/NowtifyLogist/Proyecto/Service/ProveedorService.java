package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Proveedor;

import java.util.List;

public interface ProveedorService {

    List<Proveedor> findAll();
    Proveedor findById(int id);
    void save(Proveedor proveedor);
    void update(Proveedor proveedor);
    void delete(Proveedor proveedor);
}
