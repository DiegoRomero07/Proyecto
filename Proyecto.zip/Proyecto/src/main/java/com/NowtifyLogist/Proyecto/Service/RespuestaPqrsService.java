package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.RespuestaPqrs;

import java.util.List;

public interface RespuestaPqrsService {

    List<RespuestaPqrs> findAll();
    RespuestaPqrs findById(int id);
    void save(RespuestaPqrs respuestaPqrs);
    void update(RespuestaPqrs respuestaPqrs);
    void delete(RespuestaPqrs respuestaPqrs);
}
