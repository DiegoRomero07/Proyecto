package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Rol;

import java.util.List;

public interface RolService {

    List<Rol> findAll();
    Rol findById(int id);
    void save(Rol rol);
    void update(Rol rol);
    void delete(Rol rol);
}
