package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.SalidaInventario;

import java.util.List;

public interface SalidaInventarioService {

    List<SalidaInventario> findAll();
    SalidaInventario findById(int id);
    void save(SalidaInventario salidaInventario);
    void update(SalidaInventario salidaInventario);
    void delete(SalidaInventario salidaInventario);
}
