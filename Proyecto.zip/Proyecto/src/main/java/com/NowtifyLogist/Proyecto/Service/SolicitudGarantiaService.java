package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.SolicitudGarantia;

import java.util.List;

public interface SolicitudGarantiaService {

    List<SolicitudGarantia> findAll();
    SolicitudGarantia findById(int id);
    void save(SolicitudGarantia solicitudGarantia);
    void update(SolicitudGarantia solicitudGarantia);
    void delete(SolicitudGarantia solicitudGarantia);
}
