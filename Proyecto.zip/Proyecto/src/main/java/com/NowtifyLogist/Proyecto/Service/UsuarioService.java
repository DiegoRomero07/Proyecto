package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Usuario;

import java.util.List;

public interface UsuarioService {

    List<Usuario> findAll();
    Usuario findById(int id);
    void save(Usuario usuario);
    void update(Usuario usuario);
    void delete(Usuario usuario);
}
