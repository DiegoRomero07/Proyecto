package com.NowtifyLogist.Proyecto.Service;

import com.NowtifyLogist.Proyecto.Entity.Venta;

import java.util.List;

public interface VentaService {

    List<Venta> findAll();
    Venta findById(int id);
    void save(Venta venta);
    void update(Venta venta);
    void delete(Venta venta);
}
